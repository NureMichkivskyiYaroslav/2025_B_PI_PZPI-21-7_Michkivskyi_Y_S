import {
    getDate,
    getThumbnailUrl,
} from '../src/shared/helpers/cloudinary.helper'

describe('getThumbnailUrl', () => {
    it('returns thumbnail URL for valid Cloudinary JPG link', () => {
        const link =
            'https://res.cloudinary.com/dj9cbedye/image/upload/v1234567890/photo123.jpg'
        const result = getThumbnailUrl(link)
        expect(result).toBe(
            'https://res.cloudinary.com/dj9cbedye/image/upload/c_thumb,w_500,h_500,q_auto:good,f_auto/photo123.jpg',
        )
    })

    it('returns original link for non-JPG link', () => {
        const link =
            'https://res.cloudinary.com/dj9cbedye/image/upload/v1234567890/photo123.png'
        const result = getThumbnailUrl(link)
        expect(result).toBe(link)
    })

    it('returns original link for invalid Cloudinary link', () => {
        const link = 'https://example.com/image.jpg'
        const result = getThumbnailUrl(link)
        expect(result).toBe(link)
    })
})

describe('getDate', () => {
    it('returns formatted date for valid Cloudinary link with timestamp', () => {
        const link =
            'https://res.cloudinary.com/dj9cbedye/image/upload/v1625097600/photo123.jpg'
        const result = getDate(link)
        // Timestamp 1625097600 = July 1, 2021
        expect(result).toBe('July 1, 2021')
    })

    it('returns "Unknown Date" for link without timestamp', () => {
        const link =
            'https://res.cloudinary.com/dj9cbedye/image/upload/photo123.jpg'
        const result = getDate(link)
        expect(result).toBe('Unknown Date')
    })

    it('returns "Unknown Date" for invalid link', () => {
        const link = 'https://example.com/image.jpg'
        const result = getDate(link)
        expect(result).toBe('Unknown Date')
    })
})
