import { jwtDecode } from 'jwt-decode'
import { decodeToken } from '../src/shared/helpers/jwt.helper'
import { JwtPayload } from '../src/shared/helpers/jwtPayload.interface'

jest.mock('jwt-decode')

describe('decodeToken', () => {
    const mockJwtDecode = jwtDecode as jest.MockedFunction<typeof jwtDecode>
    let mockLocalStorageRemoveItem: jest.SpyInstance

    beforeEach(() => {
        jest.clearAllMocks()
        mockLocalStorageRemoveItem = jest.spyOn(Storage.prototype, 'removeItem')
    })

    it('returns UserState for valid token', () => {
        const token = 'valid-token'
        const decoded: JwtPayload = {
            sub: 'user123',
            name: 'Test User',
            exp: Math.floor(Date.now() / 1000) + 3600,
        }
        mockJwtDecode.mockReturnValue(decoded)

        const result = decodeToken(token)
        expect(result).toEqual({ id: 'user123', name: 'Test User' })
        expect(mockJwtDecode).toHaveBeenCalledWith(token)
        expect(mockLocalStorageRemoveItem).not.toHaveBeenCalled()
    })

    it('returns null and removes token for expired token', () => {
        const token = 'expired-token'
        const decoded: JwtPayload = {
            sub: 'user123',
            name: 'Test User',
            exp: Math.floor(Date.now() / 1000) - 3600,
        }
        mockJwtDecode.mockReturnValue(decoded)

        const result = decodeToken(token)
        expect(result).toBeNull()
        expect(mockJwtDecode).toHaveBeenCalledWith(token)
        expect(mockLocalStorageRemoveItem).toHaveBeenCalledWith('token')
    })

    it('returns null for invalid token', () => {
        const token = 'invalid-token'
        mockJwtDecode.mockImplementation(() => {
            throw new Error('Invalid token')
        })

        const result = decodeToken(token)
        expect(result).toBeNull()
        expect(mockJwtDecode).toHaveBeenCalledWith(token)
        expect(mockLocalStorageRemoveItem).not.toHaveBeenCalled()
    })
})
