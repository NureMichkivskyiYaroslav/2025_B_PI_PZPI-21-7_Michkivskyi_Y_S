import ReactDOM from 'react-dom/client'
import { QueryClientProvider } from '@tanstack/react-query'
import App from './App'
import './global.css'
import { ThemeProvider } from './shared/components/themeProvider.component'
import { AppProvider } from './shared/store/app-provider.component.tsx'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { queryClient } from './shared/api/queryClient.instance.ts'

ReactDOM.createRoot(document.getElementById('root')!).render(
    <QueryClientProvider client={queryClient}>
        <ThemeProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
                <AppProvider>
                    <App />
                </AppProvider>
            </LocalizationProvider>
        </ThemeProvider>
    </QueryClientProvider>,
)
