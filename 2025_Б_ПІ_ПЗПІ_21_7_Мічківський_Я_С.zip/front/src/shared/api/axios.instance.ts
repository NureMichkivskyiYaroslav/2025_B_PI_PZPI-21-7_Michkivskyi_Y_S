import axios from 'axios'
import { toast } from 'react-toastify'

const url = import.meta.env.VITE_API_BASE_URL

export const axiosInstance = axios.create({
    baseURL: url,
})

export const axiosAuthInstance = axios.create({
    baseURL: url,
})

axiosInstance.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token')
        if (token) {
            config.headers!.Authorization = `Bearer ${token}`
        }
        return config
    },
    (error) => {
        toast.error('Something went wrong')
        return Promise.reject(error)
    },
)

axiosInstance.interceptors.response.use(
    (response) => response,
    async (error) => {
        if (error.response) {
            const { status } = error.response

            if (status === 401 && localStorage.getItem('token')) {
                localStorage.removeItem('token')
                window.location.href = '/login'
            }
        }
        return Promise.reject(error)
    },
)

// export default axiosInstance
