import { Tag } from './tag.interface.ts'

export interface Event {
    access_type: 'owner' | 'editor' | 'viewer'
    id: string
    owner: {
        user_id: string
        user_name: string
    }
    name: string
    description: string
    date: string
    status: 'scheduled' | 'completed' | 'canceled' | 'active'
    tags: string[]
    tag_objects: Tag[]
    is_comments_allowed: boolean
    image_ids: string[]
    is_public: boolean
    comments: Comment[]
    can_edit_users: Editor[]
    created_at: string
    updated_at: string
}

export interface Comment {
    id: string
    content: string
    user_id: string
    user: {
        id: string
        email: string
        name: string
        avatar_link: string
    }
    created_at: string
    updated_at: string
}

export interface Editor {
    id: string
    name: string
    email: string
    avatar_link: string
    firebase_id: string
    free_space: number
    storage_size: number
    created_at: string
    updated_at: string
}

export interface DashboardResponse {
    my_events: Event[]
    friends_events: Event[]
    can_edit_events: Event[]
}
