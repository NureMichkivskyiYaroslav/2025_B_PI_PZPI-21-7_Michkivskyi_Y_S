export interface Image {
    id: string
    file_name: string
    link: string
    size: number
}
