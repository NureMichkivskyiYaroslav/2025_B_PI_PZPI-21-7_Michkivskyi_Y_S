export interface Friend {
    user_id: string
    user_name: string
    friend_status: string
    request_id: string | undefined
}
