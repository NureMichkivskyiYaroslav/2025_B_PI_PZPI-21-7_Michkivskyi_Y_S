export interface Tag {
    id: string
    name: string
}
