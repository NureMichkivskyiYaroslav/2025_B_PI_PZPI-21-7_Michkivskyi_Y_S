import { Palette, PaletteOptions } from '@mui/material/styles'

declare module '@mui/material/styles' {
    interface Palette {
        gradient: {
            start: string
            end: string
        }
        tag: {
            main: string
            contrastText: string
        }
    }

    interface PaletteOptions {
        gradient?: {
            start: string
            end: string
        }
        tag?: {
            main: string
            contrastText: string
        }
    }
}
