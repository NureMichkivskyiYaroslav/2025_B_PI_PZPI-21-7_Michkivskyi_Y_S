import { Box } from '@mui/material';
import { ReactNode } from 'react';
import Header from "./header.component.tsx";
import Footer from "./footer.component.tsx";

export default function DefaultLayout(props:{ children: ReactNode }){
    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            <Header />
            <Box component="main" sx={{ flexGrow: 1, py: 3 }}>
                {props.children}
            </Box>
            <Footer />
        </Box>
    );
};