import { Navigate, useLocation } from 'react-router-dom'
import { ReactNode } from 'react'
import { useAuth } from '../hooks/use-auth.hook.ts'

export default function ProtectedRoute(props: { children: ReactNode }) {
    const { isAuthenticated } = useAuth()
    const location = useLocation()

    if (!isAuthenticated) {
        return (
            <Navigate to="/login" state={{ from: location.pathname }} replace />
        )
    }
    return <>{props.children}</>
}
