import { Box, Typography, Grid, Link, useTheme } from '@mui/material';

export default function Footer() {
    const theme = useTheme();

    return (
        <Box
            component="footer"
            sx={{
                bgcolor: theme.palette.background.paper,
                color: theme.palette.text.secondary,
                py: 4,
                borderTop: `1px solid ${theme.palette.divider}`,
            }}
        >
            <Grid container spacing={3} sx={{ maxWidth: 'xl', mx: 'auto', px: { xs: 2, sm: 3 } }}>
                <Grid size={{ xs: 12, sm: 4 }}>
                    <Typography
                        variant="h6"
                        sx={{
                            color: theme.palette.primary.main,
                            fontWeight: 600,
                            mb: 1,
                        }}
                    >
                        Diary of Events
                    </Typography>
                    <Typography variant="body2" sx={{ color: theme.palette.text.secondary }}>
                        Your best diary for the best memories.
                    </Typography>
                </Grid>
                <Grid size={{ xs: 12, sm: 4 }}>
                    <Typography
                        variant="h6"
                        sx={{
                            color: theme.palette.primary.main,
                            fontWeight: 600,
                            mb: 1,
                        }}
                    >
                        Links
                    </Typography>
                    <Link
                        href="/about"
                        sx={{
                            color: theme.palette.text.secondary,
                            textDecoration: 'none',
                            display: 'block',
                            mb: 0.5,
                            '&:hover': { color: theme.palette.primary.main },
                        }}
                    >
                        About Us
                    </Link>
                    <Link
                        href="/contact"
                        sx={{
                            color: theme.palette.text.secondary,
                            textDecoration: 'none',
                            display: 'block',
                            mb: 0.5,
                            '&:hover': { color: theme.palette.primary.main },
                        }}
                    >
                        Contact
                    </Link>
                    <Link
                        href="/terms"
                        sx={{
                            color: theme.palette.text.secondary,
                            textDecoration: 'none',
                            display: 'block',
                            mb: 0.5,
                            '&:hover': { color: theme.palette.primary.main },
                        }}
                    >
                        Terms of Service
                    </Link>
                </Grid>
                <Grid size={{ xs: 12, sm: 4 }}>
                    <Typography
                        variant="h6"
                        sx={{
                            color: theme.palette.primary.main,
                            fontWeight: 600,
                            mb: 1,
                        }}
                    >
                        Contact
                    </Typography>
                    <Typography variant="body2" sx={{ color: theme.palette.text.secondary, mb: 0.5 }}>
                        Email: support@diary.com
                    </Typography>
                    <Typography variant="body2" sx={{ color: theme.palette.text.secondary }}>
                        Phone: +1 (555) 123-4567
                    </Typography>
                </Grid>
                <Grid size={12}>
                    <Typography
                        variant="body2"
                        align="center"
                        sx={{ mt: 3, color: theme.palette.text.secondary }}
                    >
                        © {new Date().getFullYear()} Diary. All rights reserved.
                    </Typography>
                </Grid>
            </Grid>
        </Box>
    );
}