import React, { createContext, useState, useMemo, useContext } from 'react'
import { ThemeProvider as MuiThemeProvider, CssBaseline } from '@mui/material'
import { darkTheme, lightTheme } from '../../themes.ts'

interface ThemeContextType {
    toggleTheme: () => void
    isDarkMode: boolean
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
        const savedTheme = localStorage.getItem('theme')
        return savedTheme === 'dark'
    })

    const theme = useMemo(() => (isDarkMode ? darkTheme : lightTheme), [isDarkMode])

    const toggleTheme = () => {
        const newMode = !isDarkMode
        setIsDarkMode(newMode)
        localStorage.setItem('theme', newMode ? 'dark' : 'light')
    }

    return (
        <ThemeContext.Provider value={{ toggleTheme, isDarkMode }}>
            <MuiThemeProvider theme={theme}>
                <CssBaseline />
                {children}
            </MuiThemeProvider>
        </ThemeContext.Provider>
    )
}

export const useTheme = (): ThemeContextType => {
    const context = useContext(ThemeContext)
    if (context === undefined) {
        throw new Error('useTheme must be used within a ThemeProvider')
    }
    return context
}
