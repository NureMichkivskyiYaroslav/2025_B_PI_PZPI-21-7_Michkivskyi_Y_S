import {
    Card,
    CardContent,
    CardMedia,
    Typography,
    useTheme,
} from '@mui/material'
import { Link } from 'react-router-dom'
import { Event } from '../common/interfaces/event.interface.ts'
import { generateImageUrl } from '../helpers/cloudinary.helper.ts'

interface EventCardProps {
    event: Event
}

export default function EventCard({ event }: EventCardProps) {
    const theme = useTheme()
    const uniqueImageIds = [...new Set(event.image_ids)]
    const imageUrl = uniqueImageIds[0]
        ? generateImageUrl(uniqueImageIds[0])
        : 'https://via.placeholder.com/300'

    return (
        <Card
            component={Link}
            to={`/events/${event.id}`}
            sx={{
                width: 350,
                textDecoration: 'none',
                transition: 'transform 0.2s, box-shadow 0.2s',
                '&:hover': {
                    transform: 'scale(1.05)',
                    boxShadow: theme.shadows[8],
                },
                height: 350,
                display: 'flex',
                flexDirection: 'column',
            }}
        >
            <CardMedia
                component="img"
                height="140"
                image={imageUrl}
                alt={event.name}
                sx={{ objectFit: 'cover' }}
            />
            <CardContent sx={{ flexGrow: 1 }}>
                <Typography variant="h6" noWrap>
                    {event.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    Owner: {event.owner.user_name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    Date: {new Date(event.date).toLocaleDateString()}
                </Typography>
            </CardContent>
        </Card>
    )
}
