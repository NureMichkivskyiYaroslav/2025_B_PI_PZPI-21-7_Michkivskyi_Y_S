import { ChangeEvent, useEffect, useRef, useState } from 'react'
import {
    Box,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
} from '@mui/material'
import RotateLeftIcon from '@mui/icons-material/RotateLeft'
import RotateRightIcon from '@mui/icons-material/RotateRight'
import CropIcon from '@mui/icons-material/Crop'
import { Cropper, CropperRef } from 'react-advanced-cropper'
import 'react-advanced-cropper/dist/style.css'
import { useTheme } from '@mui/material/styles'

interface UploadModalProps {
    open: boolean
    isUploading: boolean
    selectedFile: File | null
    onClose: () => void
    onFileChange: (event: ChangeEvent<HTMLInputElement>) => void
    onUpload: (croppedImage: File) => void
}

export default function UploadModal({
    open,
    isUploading,
    selectedFile,
    onClose,
    onFileChange,
    onUpload,
}: UploadModalProps) {
    const theme = useTheme()
    const [imageSrc, setImageSrc] = useState<string | null>(null)
    const cropperRef = useRef<CropperRef>(null)
    const fileInputRef = useRef<HTMLInputElement>(null)

    useEffect(() => {
        if (selectedFile) {
            const reader = new FileReader()
            reader.onload = () => setImageSrc(reader.result as string)
            reader.readAsDataURL(selectedFile)
        } else {
            setImageSrc(null)
        }
    }, [selectedFile])

    const getCroppedImage = async (): Promise<File> => {
        if (!cropperRef.current || !imageSrc) {
            throw new Error('No image or cropper available')
        }

        const canvas = cropperRef.current.getCanvas()
        if (!canvas) {
            throw new Error('Failed to get cropped canvas')
        }

        return new Promise((resolve) => {
            canvas.toBlob((blob) => {
                if (blob) {
                    resolve(
                        new File([blob], 'cropped-image.jpg', {
                            type: 'image/jpeg',
                        }),
                    )
                }
            }, 'image/jpeg')
        })
    }

    const handleUpload = async () => {
        try {
            const croppedImage = await getCroppedImage()
            onUpload(croppedImage)
        } catch (error) {
            console.error('Failed to crop image:', error)
        }
    }

    const handleRotate = (direction: 'left' | 'right') => {
        cropperRef.current?.rotateImage(direction === 'left' ? -90 : 90)
    }

    const handleFileSelect = () => {
        fileInputRef.current?.click()
    }

    return (
        <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
            <DialogTitle>Upload and Edit Image</DialogTitle>
            <DialogContent>
                <Box sx={{ minHeight: 400, position: 'relative' }}>
                    {imageSrc ? (
                        <>
                            <Cropper
                                ref={cropperRef}
                                src={imageSrc}
                                stencilProps={{
                                    movable: true,
                                    resizable: true,
                                    handlers: true,
                                }}
                                minWidth={50}
                                minHeight={50}
                                backgroundProps={{
                                    scale: 1,
                                }}
                            />
                            <Box
                                sx={{
                                    display: 'flex',
                                    gap: 1,
                                    mt: 2,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                }}
                            >
                                <IconButton
                                    onClick={() => handleRotate('left')}
                                >
                                    <RotateLeftIcon />
                                </IconButton>
                                <IconButton
                                    onClick={() => handleRotate('right')}
                                >
                                    <RotateRightIcon />
                                </IconButton>
                                <IconButton onClick={handleFileSelect}>
                                    <CropIcon />
                                </IconButton>
                            </Box>
                        </>
                    ) : (
                        <Box
                            sx={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                height: 400,
                                bgcolor: theme.palette.grey[200],
                                borderRadius: 2,
                            }}
                        >
                            <Button
                                variant="contained"
                                onClick={handleFileSelect}
                            >
                                Select Image
                            </Button>
                        </Box>
                    )}
                    <input
                        type="file"
                        accept="image/*"
                        onChange={onFileChange}
                        ref={fileInputRef}
                        style={{ display: 'none' }}
                    />
                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose} disabled={isUploading}>
                    Cancel
                </Button>
                <Button
                    onClick={handleUpload}
                    variant="contained"
                    disabled={!imageSrc || isUploading}
                    startIcon={
                        isUploading ? <CircularProgress size={20} /> : null
                    }
                >
                    {isUploading ? 'Uploading...' : 'Upload'}
                </Button>
            </DialogActions>
        </Dialog>
    )
}
