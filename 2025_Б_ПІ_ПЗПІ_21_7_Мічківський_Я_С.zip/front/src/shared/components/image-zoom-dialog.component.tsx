import { Box, Dialog, IconButton, useTheme } from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { ArrowBack, ArrowForward, ZoomIn, ZoomOut } from '@mui/icons-material'
import { TransformComponent, TransformWrapper } from 'react-zoom-pan-pinch'
import { Image } from '../common/interfaces/image.interface.ts'

interface ImageZoomDialogProps {
    image: Image | null
    onClose: () => void
    onNavigate: (direction: 'prev' | 'next') => void
}

export default function ImageZoomDialog({
    image,
    onClose,
    onNavigate,
}: ImageZoomDialogProps) {
    const theme = useTheme()
    if (!image) return null

    return (
        <Dialog
            open={!!image}
            onClose={onClose}
            maxWidth={false}
            sx={{
                '& .MuiDialog-paper': {
                    bgcolor: 'transparent',
                    boxShadow: 'none',
                    m: 0,
                    maxWidth: '100%',
                    maxHeight: '100%',
                    width: '100%',
                    height: '100%',
                },
            }}
        >
            <Box
                sx={{ bgcolor: 'rgba(0, 0, 0, 0.9)' }}
                className="flex items-center justify-center h-screen relative"
            >
                <IconButton
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        top: 16,
                        right: 16,
                        color: theme.palette.common.white,
                    }}
                >
                    <CloseIcon fontSize="large" />
                </IconButton>
                <IconButton
                    onClick={() => onNavigate('prev')}
                    sx={{
                        position: 'absolute',
                        left: 16,
                        color: theme.palette.common.white,
                    }}
                >
                    <ArrowBack fontSize="large" />
                </IconButton>
                <IconButton
                    onClick={() => onNavigate('next')}
                    sx={{
                        position: 'absolute',
                        right: 16,
                        color: theme.palette.common.white,
                    }}
                >
                    <ArrowForward fontSize="large" />
                </IconButton>
                <TransformWrapper
                    initialScale={1}
                    minScale={0.5}
                    maxScale={3}
                    centerOnInit
                    wheel={{ step: 0.1 }}
                >
                    {({ zoomIn, zoomOut, resetTransform }) => (
                        <>
                            <Box
                                sx={{
                                    position: 'absolute',
                                    bottom: 16,
                                    left: '50%',
                                    transform: 'translateX(-50%)',
                                    display: 'flex',
                                    gap: 1,
                                }}
                            >
                                <IconButton
                                    onClick={() => zoomIn()}
                                    sx={{ color: theme.palette.common.white }}
                                >
                                    <ZoomIn />
                                </IconButton>
                                <IconButton
                                    onClick={() => zoomOut()}
                                    sx={{ color: theme.palette.common.white }}
                                >
                                    <ZoomOut />
                                </IconButton>
                            </Box>
                            <TransformComponent
                                wrapperStyle={{
                                    width: '90%',
                                    height: '90%',
                                }}
                                contentStyle={{
                                    width: '100%',
                                    height: '100%',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                }}
                            >
                                <img
                                    src={image.link}
                                    alt="full-screen"
                                    className="max-w-[90%] max-h-[90%] object-contain"
                                    onDoubleClick={() => resetTransform()}
                                />
                            </TransformComponent>
                        </>
                    )}
                </TransformWrapper>
            </Box>
        </Dialog>
    )
}
