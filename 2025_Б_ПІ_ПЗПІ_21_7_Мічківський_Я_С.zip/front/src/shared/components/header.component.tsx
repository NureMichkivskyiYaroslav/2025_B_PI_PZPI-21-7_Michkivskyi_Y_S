import {
    AppBar,
    Avatar,
    Box,
    IconButton,
    Menu,
    MenuItem,
    Toolbar,
    Tooltip,
    useMediaQuery,
    useTheme,
} from '@mui/material'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/use-auth.hook'
import ThemeToggle from './themeToggle.component'
import MenuIcon from '@mui/icons-material/Menu'
import PhotoLibraryIcon from '@mui/icons-material/PhotoLibrary'
import SearchIcon from '@mui/icons-material/Search'
import AddCircleIcon from '@mui/icons-material/AddCircle'
import { useState } from 'react'

export default function Header() {
    const theme = useTheme()
    const navigate = useNavigate()
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('md'))
    const { user } = useAuth()
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
    const open = Boolean(anchorEl)

    const logoSrc = isSmallScreen
        ? theme.palette.mode === 'light'
            ? '/src/assets/logo-mini-light.svg'
            : '/src/assets/logo-mini-dark.svg'
        : theme.palette.mode === 'light'
          ? '/src/assets/logo-full-light.svg'
          : '/src/assets/logo-full-dark.svg'

    const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget)
    }

    const handleMenuClose = () => {
        setAnchorEl(null)
    }

    const handleNavigate = (path: string) => {
        navigate(path)
        handleMenuClose()
    }

    return (
        <AppBar
            position="static"
            elevation={1}
            sx={{
                bgcolor: theme.palette.background.paper,
                color: theme.palette.text.primary,
            }}
        >
            <Toolbar sx={{ justifyContent: 'space-between' }}>
                <Box
                    component="img"
                    src={logoSrc}
                    alt="Diary Logo"
                    sx={{ height: 65, cursor: 'pointer', py: 1 }}
                    onClick={() => navigate('/dashboard')}
                />
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    {!isSmallScreen ? (
                        <>
                            <Tooltip title="View Archive">
                                <IconButton
                                    color="inherit"
                                    onClick={() => navigate('/archive')}
                                >
                                    <PhotoLibraryIcon />
                                </IconButton>
                            </Tooltip>
                            <Tooltip title="Search Events">
                                <IconButton
                                    color="inherit"
                                    onClick={() => navigate('/events/search')}
                                >
                                    <SearchIcon />
                                </IconButton>
                            </Tooltip>
                            <Tooltip title="Create New Event">
                                <IconButton
                                    color="inherit"
                                    onClick={() => navigate('/events/new')}
                                >
                                    <AddCircleIcon />
                                </IconButton>
                            </Tooltip>
                            <ThemeToggle />
                            <Avatar
                                sx={{
                                    bgcolor: theme.palette.secondary.main,
                                    color: theme.palette.secondary.contrastText,
                                    cursor: 'pointer',
                                    width: 36,
                                    height: 36,
                                }}
                                onClick={() => navigate('/profile')}
                            >
                                {user?.name?.[0]?.toUpperCase() || 'U'}
                            </Avatar>
                        </>
                    ) : (
                        <>
                            <ThemeToggle />
                            <IconButton
                                color="inherit"
                                onClick={handleMenuOpen}
                            >
                                <MenuIcon />
                            </IconButton>
                        </>
                    )}
                </Box>
            </Toolbar>
            <Menu
                anchorEl={anchorEl}
                open={open}
                onClose={handleMenuClose}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            >
                <MenuItem onClick={() => handleNavigate('/profile')}>
                    <Avatar
                        sx={{
                            bgcolor: theme.palette.secondary.main,
                            color: theme.palette.secondary.contrastText,
                            width: 24,
                            height: 24,
                            mr: 1,
                        }}
                    >
                        {user?.name?.[0]?.toUpperCase() || 'U'}
                    </Avatar>
                    Profile
                </MenuItem>
                <MenuItem onClick={() => handleNavigate('/archive')}>
                    <PhotoLibraryIcon sx={{ mr: 1 }} />
                    View Archive
                </MenuItem>
                <MenuItem onClick={() => handleNavigate('/events/search')}>
                    <SearchIcon sx={{ mr: 1 }} />
                    Search Events
                </MenuItem>
                <MenuItem onClick={() => handleNavigate('/events/new')}>
                    <AddCircleIcon sx={{ mr: 1 }} />
                    Create New Event
                </MenuItem>
            </Menu>
        </AppBar>
    )
}
