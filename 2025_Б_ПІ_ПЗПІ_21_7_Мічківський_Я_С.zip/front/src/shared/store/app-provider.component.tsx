import React from 'react'
import { AppContext, AppContextValue } from './app.context'
import { useAuthActions } from './auth/auth.actions.ts'

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const auth = useAuthActions()

    const contextValue: AppContextValue = {
        auth,
    }

    return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>
}
