import { useState, useEffect } from 'react'
import { decodeToken } from '../../helpers/jwt.helper'
import { AuthState, AuthContextValue } from './auth.interface'
import { queryClient } from '../../api/queryClient.instance.ts'

export const useAuthActions = (): AuthContextValue => {
    const initialToken = localStorage.getItem('token')
    const initialUser = initialToken ? decodeToken(initialToken) : null

    const [state, setState] = useState<AuthState>({
        user: initialUser || null,
        isAuthenticated: !!initialUser,
        token: initialToken || null,
    })

    const login = (token: string) => {
        const user = decodeToken(token)
        if (user) {
            localStorage.setItem('token', token)
            setState({
                user,
                isAuthenticated: true,
                token,
            })
        }
    }

    const logout = () => {
        localStorage.removeItem('token')
        queryClient.clear()
        setState({
            user: null,
            isAuthenticated: false,
            token: null,
        })
    }

    useEffect(() => {
        const token = localStorage.getItem('token')
        if (token && token !== state.token) {
            const user = decodeToken(token)
            if (user) {
                setState({
                    user,
                    isAuthenticated: true,
                    token,
                })
            }
        } else if (!token && state.token) {
            setState({
                user: null,
                isAuthenticated: false,
                token: null,
            })
        }
    }, [state.token])

    return {
        ...state,
        login,
        logout,
    }
}
