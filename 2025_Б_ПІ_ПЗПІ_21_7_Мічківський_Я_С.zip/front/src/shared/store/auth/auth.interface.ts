export interface UserState {
    id: string
    name: string
}

export interface AuthState {
    user: UserState | null
    isAuthenticated: boolean
    token: string | null
}

export interface AuthActions {
    login: (token: string) => void
    logout: () => void
}

export interface AuthContextValue extends AuthState, AuthActions {}
