import { createContext } from 'react'
import { AuthContextValue } from './auth.interface.ts'

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export { AuthContext }
