import { createContext } from 'react'
import { AuthContextValue } from './auth/auth.interface'

export interface AppContextValue {
    auth: AuthContextValue
}

const AppContext = createContext<AppContextValue | undefined>(undefined)

export { AppContext }
