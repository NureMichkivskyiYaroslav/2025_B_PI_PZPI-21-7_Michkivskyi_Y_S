export interface JwtPayload {
    sub: string
    name: string
    exp: number

    [key: string]: any
}
