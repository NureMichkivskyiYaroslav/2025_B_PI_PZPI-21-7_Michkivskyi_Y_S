const baseUrl = import.meta.env.VITE_CLOUDINARY_BASE_URL

export const getThumbnailUrl = (link: string): string => {
    const publicId = link.match(/upload\/v\d+\/(.+)\.jpg$/)?.[1]
    return publicId
        ? `${baseUrl}/c_thumb,w_500,h_500,q_auto:good,f_auto/${publicId}.jpg`
        : link
}

export const generateImageUrl = (imageId: string): string => {
    return `${baseUrl}/v1749248715/${imageId}.jpg`
}

export const getDate = (link: string): string => {
    const timestamp = link.match(/v(\d+)/)?.[1]
    return timestamp
        ? new Date(Number(timestamp) * 1000).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
          })
        : 'Unknown Date'
}
