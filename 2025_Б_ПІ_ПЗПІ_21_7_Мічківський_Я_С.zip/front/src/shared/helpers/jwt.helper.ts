import { jwtDecode } from 'jwt-decode'
import { UserState } from '../store/auth/auth.interface'
import { JwtPayload } from './jwtPayload.interface'

const decodeToken = (token: string): UserState | null => {
    try {
        const decoded = jwtDecode<JwtPayload>(token)

        const currentTime = Date.now() / 1000
        if (decoded.exp < currentTime) {
            localStorage.removeItem('token')
            return null
        }

        return {
            id: decoded.sub,
            name: decoded.name,
        }
    } catch (error) {
        console.error('Failed to decode token:', error)
        return null
    }
}

export { decodeToken }
