import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { axiosInstance } from '../api/axios.instance'

const postCommentApi = async (
    eventId: string,
    content: string,
): Promise<void> => {
    await axiosInstance.post(`/event/${eventId}/comment`, { content })
}

export const useComments = (eventId: string) => {
    const queryClient = useQueryClient()

    const { mutate: postComment } = useMutation({
        mutationFn: (content: string) => postCommentApi(eventId, content),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['event', eventId] })
            toast.success('Comment posted successfully!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to post comment')
        },
    })

    return { postComment }
}
