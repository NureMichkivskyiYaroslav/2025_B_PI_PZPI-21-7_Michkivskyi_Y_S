import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { axiosInstance } from '../api/axios.instance.ts'
import { Tag } from '../common/interfaces/tag.interface.ts'

const fetchTags = async (): Promise<Tag[]> => {
    const response = await axiosInstance.get('/tag')
    return response.data
}

const createTagApi = async (tag: { name: string }): Promise<Tag> => {
    const response = await axiosInstance.post('/tag', tag)
    return response.data
}

const deleteTagApi = async (id: string): Promise<void> => {
    await axiosInstance.delete(`/tag/${id}`)
}

export function useTags() {
    const queryClient = useQueryClient()

    const { data: tags = [], isLoading: isLoadingTags } = useQuery({
        queryKey: ['tags'],
        queryFn: fetchTags,
    })

    const { mutate: createTag, isPending: isCreatingTag } = useMutation({
        mutationFn: createTagApi,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tags'] })
            toast.success('Tag created successfully!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to create tag')
        },
    })

    const { mutate: deleteTag, isPending: isDeletingTag } = useMutation({
        mutationFn: deleteTagApi,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tags'] })
            toast.success('Tag deleted successfully!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to delete tag')
        },
    })

    return {
        tags,
        isLoadingTags,
        createTag,
        isCreatingTag,
        deleteTag,
        isDeletingTag,
        error: null, // No error state needed, handled via toast
    }
}
