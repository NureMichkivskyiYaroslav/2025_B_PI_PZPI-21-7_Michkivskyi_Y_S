import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { axiosInstance } from '../api/axios.instance'
import { Friend } from '../common/interfaces/friend.interface'

const fetchFriends = async (): Promise<Friend[]> => {
    const response = await axiosInstance.get('/profile/friends')
    return response.data
}

const fetchOutgoingRequests = async (): Promise<Friend[]> => {
    const response = await axiosInstance.get('/profile/friends/outgoing')
    return response.data
}

const fetchIncomingRequests = async (): Promise<Friend[]> => {
    const response = await axiosInstance.get('/profile/friends/incoming')
    return response.data
}

const searchUsersApi = async (name: string): Promise<Friend[]> => {
    const response = await axiosInstance.get(
        `/profile/friends/search?name=${encodeURIComponent(name)}`,
    )
    return response.data
}

const sendFriendRequestApi = async (userId: string): Promise<void> => {
    await axiosInstance.post(`/profile/friends/${userId}`)
}

const acceptFriendRequestApi = async (requestId: string): Promise<void> => {
    await axiosInstance.put(`/profile/friends/${requestId}/accept`)
}

const rejectFriendRequestApi = async (requestId: string): Promise<void> => {
    await axiosInstance.put(`/profile/friends/${requestId}/reject`)
}

const deleteFriendApi = async (requestId: string): Promise<void> => {
    await rejectFriendRequestApi(requestId)
}

export function useFriends() {
    const queryClient = useQueryClient()

    const {
        data: friends = [],
        isLoading: isLoadingFriends,
        error: errorFetching,
    } = useQuery({
        queryKey: ['friends'],
        queryFn: fetchFriends,
    })

    const { data: outgoingRequests = [], isLoading: isLoadingOutgoing } =
        useQuery({
            queryKey: ['outgoingRequests'],
            queryFn: fetchOutgoingRequests,
        })

    const { data: incomingRequests = [], isLoading: isLoadingIncoming } =
        useQuery({
            queryKey: ['incomingRequests'],
            queryFn: fetchIncomingRequests,
        })

    const {
        mutateAsync: searchUsers,
        isPending: isLoadingSearch,
        error: errorSearching,
    } = useMutation({
        mutationFn: searchUsersApi,
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to search users')
        },
    })

    const { mutateAsync: sendFriendRequest } = useMutation({
        mutationFn: (friend: Friend) => sendFriendRequestApi(friend.user_id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['friends'] })
            queryClient.invalidateQueries({ queryKey: ['outgoingRequests'] })
            queryClient.invalidateQueries({ queryKey: ['incomingRequests'] })
            toast.success('Friend request sent successfully!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to send friend request')
        },
    })

    const { mutateAsync: acceptFriendRequest } = useMutation({
        mutationFn: (friend: Friend) => {
            if (!friend.request_id) {
                throw new Error('Request ID is missing')
            }
            return acceptFriendRequestApi(friend.request_id)
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['friends'] })
            queryClient.invalidateQueries({ queryKey: ['outgoingRequests'] })
            queryClient.invalidateQueries({ queryKey: ['incomingRequests'] })
            toast.success('Friend request accepted!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to accept friend request')
        },
    })

    const { mutateAsync: rejectFriendRequest } = useMutation({
        mutationFn: (friend: Friend) => {
            if (!friend.request_id) {
                throw new Error('Request ID is missing')
            }
            return rejectFriendRequestApi(friend.request_id)
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['friends'] })
            queryClient.invalidateQueries({ queryKey: ['outgoingRequests'] })
            queryClient.invalidateQueries({ queryKey: ['incomingRequests'] })
            toast.success('Friend request cancelled or declined!')
        },
        onError: (error: Error) => {
            toast.error(
                error.message || 'Failed to cancel or decline friend request',
            )
        },
    })

    const { mutateAsync: deleteFriend } = useMutation({
        mutationFn: (friend: Friend) => {
            if (!friend.request_id) {
                throw new Error('Request ID is missing')
            }
            return deleteFriendApi(friend.request_id)
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['friends'] })
            queryClient.invalidateQueries({ queryKey: ['outgoingRequests'] })
            queryClient.invalidateQueries({ queryKey: ['incomingRequests'] })
            toast.success('Friend removed successfully!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to remove friend')
        },
    })

    return {
        friends,
        outgoingRequests,
        incomingRequests,
        isLoadingFriends,
        isLoadingOutgoing,
        isLoadingIncoming,
        isLoadingSearch,
        errorFetching,
        errorSearching,
        searchUsers,
        sendFriendRequest,
        acceptFriendRequest,
        rejectFriendRequest,
        deleteFriend,
        fetchFriends,
        fetchOutgoingRequests,
        fetchIncomingRequests,
    }
}
