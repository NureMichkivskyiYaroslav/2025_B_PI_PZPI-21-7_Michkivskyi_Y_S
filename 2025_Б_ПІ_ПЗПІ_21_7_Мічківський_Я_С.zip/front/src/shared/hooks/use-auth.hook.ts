import { useContext } from 'react'
import { AuthContextValue } from '../store/auth/auth.interface.ts'
import { AppContext } from '../store/app.context.tsx'

export const useAuth = (): AuthContextValue => {
    const context = useContext(AppContext)
    if (!context) {
        throw new Error('useAuth must be used within an AppProvider')
    }
    return context.auth
}
