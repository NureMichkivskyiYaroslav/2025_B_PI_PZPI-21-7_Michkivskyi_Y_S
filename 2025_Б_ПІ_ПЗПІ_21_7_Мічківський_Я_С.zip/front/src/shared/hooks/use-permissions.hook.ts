// useEditorPermissions.ts
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { axiosInstance } from '../api/axios.instance'

const addEditorPermissionApi = async (
    eventId: string,
    userId: string,
): Promise<void> => {
    await axiosInstance.patch(`/event/${eventId}`, { permission_to_id: userId })
}

const removeEditorPermissionApi = async (
    eventId: string,
    userId: string,
): Promise<void> => {
    await axiosInstance.patch(`/event/${eventId}/remove-permission`, {
        permission_to_id: userId,
    })
}

export const useEditorPermissions = (eventId: string) => {
    const queryClient = useQueryClient()

    const { mutate: addEditorPermission } = useMutation({
        mutationFn: (userId: string) => addEditorPermissionApi(eventId, userId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['event', eventId] })
            toast.success('Editor permission added successfully!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to add editor permission')
        },
    })

    const { mutate: removeEditorPermission } = useMutation({
        mutationFn: (userId: string) =>
            removeEditorPermissionApi(eventId, userId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['event', eventId] })
            toast.success('Editor permission removed successfully!')
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to remove editor permission')
        },
    })

    return { addEditorPermission, removeEditorPermission }
}
