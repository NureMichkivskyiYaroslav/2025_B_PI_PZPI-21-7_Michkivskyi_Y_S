import { useQuery } from '@tanstack/react-query'
import { axiosInstance } from '../api/axios.instance.ts'

interface Profile {
    email: string
    name: string
    created_at: string
}

const fetchProfile = async (): Promise<Profile | null> => {
    try {
        const response = await axiosInstance.get('/profile')
        return response.data
    } catch (err) {
        return null
    }
}

export function useProfile() {
    const {
        data: profile,
        isLoading: isLoadingProfile,
        error,
    } = useQuery({
        queryKey: ['profile'],
        queryFn: fetchProfile,
    })

    return {
        profile,
        isLoadingProfile,
        error: error?.message || null,
    }
}
