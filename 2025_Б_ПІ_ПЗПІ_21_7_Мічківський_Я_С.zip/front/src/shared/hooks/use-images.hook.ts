import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { Image } from '../common/interfaces/image.interface'
import { axiosInstance } from '../api/axios.instance.ts'

export interface ArchiveResponse {
    images: Image[]
    all_allowed_space: number
    free_space: number
}

export interface UploadImageResponse {
    id: string
}

export const useImages = () => {
    const queryClient = useQueryClient()

    const {
        data: archive = { images: [], all_allowed_space: 0, free_space: 0 },
        isLoading: isLoadingImages,
        error: fetchError,
    } = useQuery<ArchiveResponse>({
        queryKey: ['archive'],
        queryFn: async () => {
            try {
                const response =
                    await axiosInstance.get<ArchiveResponse>('/image')
                return response.data
            } catch (error) {
                const message =
                    error instanceof Error
                        ? error.message
                        : 'Failed to fetch images'
                toast.error(message)
                return { images: [], all_allowed_space: 0, free_space: 0 }
            }
        },
    })

    const { mutateAsync: uploadImageAsync, isPending: isUploading } =
        useMutation<UploadImageResponse, Error, File>({
            mutationFn: async (file: File) => {
                const formData = new FormData()
                formData.append('file_name', 'name')
                formData.append('image_file', file)
                const response = await axiosInstance.post<UploadImageResponse>(
                    '/image',
                    formData,
                    {
                        headers: { 'Content-Type': 'multipart/form-data' },
                    },
                )
                return response.data
            },
            onSuccess: () => {
                queryClient.invalidateQueries({ queryKey: ['archive'] })
                toast.success('Image uploaded successfully!')
            },
            onError: (error) => {
                toast.error(error.message || 'Failed to upload image')
            },
        })
    
    const { mutateAsync: removeImage, isPending: isDeleting } = useMutation<
        void,
        Error,
        string
    >({
        mutationFn: async (id: string) => {
            const response = await axiosInstance.delete(`/image/${id}`)
            if (!response.status.toString().startsWith('2')) {
                throw new Error(
                    `Failed to delete image: HTTP ${response.status}`,
                )
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['archive'] })
            toast.success('Image deleted successfully!')
        },
        onError: (error) => {
            toast.error(error.message || 'Failed to delete image')
        },
    })

    return {
        images: archive.images,
        storage_size: archive.all_allowed_space,
        free_space: archive.free_space,
        isLoadingImages,
        fetchError,
        uploadImageAsync,
        isUploading,
        removeImage,
        isDeleting,
    }
}
