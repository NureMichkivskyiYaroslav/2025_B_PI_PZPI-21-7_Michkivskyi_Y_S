import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { axiosInstance } from '../api/axios.instance.ts'
import {
    Event,
    DashboardResponse,
} from '../common/interfaces/event.interface.ts'

export interface EventFormValues {
    name: string
    description: string
    date: string
    status: 'scheduled' | 'completed' | 'canceled' | 'active'
    tags: string[]
    is_comments_allowed: boolean
    image_ids: string[]
    is_public: boolean
}

interface EventFilterParams {
    name?: string
    after_date?: string
    before_date?: string
    tags?: string[]
}

const createEventApi = async (
    values: EventFormValues,
): Promise<{ event_id: string }> => {
    const response = await axiosInstance.post('/event', values)
    return response.data
}

const updateEventApi = async (
    eventId: string,
    values: EventFormValues,
): Promise<void> => {
    await axiosInstance.put(`/event/${eventId}`, values)
}

const fetchEvent = async (eventId: string): Promise<Event> => {
    const response = await axiosInstance.get(`/event/${eventId}`)
    return response.data
}

const fetchDashboard = async (): Promise<DashboardResponse> => {
    const response = await axiosInstance.get('/dashboard')
    return response.data
}

const fetchEvents = async (params: EventFilterParams): Promise<Event[]> => {
    const queryParams = new URLSearchParams()
    if (params.name) queryParams.append('name', params.name)
    if (params.after_date) queryParams.append('after_date', params.after_date)
    if (params.before_date)
        queryParams.append('before_date', params.before_date)
    if (params.tags)
        params.tags.forEach((tag) => queryParams.append('tags', tag))
    const response = await axiosInstance.get(
        `/event/params?${queryParams.toString()}`,
    )
    return response.data
}

export const useEvents = () => {
    const navigate = useNavigate()
    const queryClient = useQueryClient()

    const { mutate: createEvent, isPending: isCreatingEvent } = useMutation({
        mutationFn: createEventApi,
        onSuccess: (data: { event_id: string }) => {
            toast.success('Event created successfully!')
            queryClient.invalidateQueries({ queryKey: ['dashboard'] })
            navigate('/events/' + data.event_id)
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to create event')
        },
    })

    const { mutate: updateEvent, isPending: isUpdatingEvent } = useMutation({
        mutationFn: ({
            eventId,
            values,
        }: {
            eventId: string
            values: EventFormValues
        }) => updateEventApi(eventId, values),
        onSuccess: (_, { eventId }) => {
            toast.success('Event updated successfully!')
            queryClient.invalidateQueries({ queryKey: ['event', eventId] })
            queryClient.invalidateQueries({ queryKey: ['dashboard'] })
            navigate(`/events/${eventId}`)
        },
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to update event')
        },
    })

    return {
        createEvent,
        isCreatingEvent,
        updateEvent,
        isUpdatingEvent,
        fetchEvents,
    }
}

export const useEvent = (eventId: string) => {
    return useQuery({
        queryKey: ['event', eventId],
        queryFn: () => fetchEvent(eventId),
    })
}

export const useDashboard = () => {
    return useQuery({
        queryKey: ['dashboard'],
        queryFn: fetchDashboard,
    })
}
