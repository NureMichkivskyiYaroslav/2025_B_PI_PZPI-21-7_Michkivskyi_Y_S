import { useMutation } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { axiosInstance } from '../api/axios.instance'

interface PaymentRequest {
    count: number // 100MB units
}

interface PaymentResponse {
    link: string // PayPal payment link
}

export const usePayment = () => {
    const { mutateAsync: createPayment, isPending: isCreatingPayment } =
        useMutation<PaymentResponse, Error, PaymentRequest>({
            mutationFn: async (data: PaymentRequest) => {
                const response = await axiosInstance.post<PaymentResponse>(
                    '/paypal/order',
                    data,
                )
                return response.data
            },
            onSuccess: (data) => {
                window.location.href = data.link // Redirect to PayPal
            },
            onError: (error) => {
                toast.error(error.message || 'Failed to initiate payment')
            },
        })

    return { createPayment, isCreatingPayment }
}
