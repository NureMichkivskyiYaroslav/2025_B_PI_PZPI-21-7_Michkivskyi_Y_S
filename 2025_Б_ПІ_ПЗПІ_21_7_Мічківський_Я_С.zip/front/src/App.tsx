import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ProtectedRoute from './shared/components/protected-route.component.tsx'
import Login from './pages/auth/login.page.tsx'
import Register from './pages/auth/register.page.tsx'
import { ToastContainer } from 'react-toastify'
import Dashboard from './pages/dashboard/dashboard.page.tsx'
import EventCreate from './pages/add-event/add-event.page.tsx'
import ArchivePage from './pages/archive/archive.page.tsx'
import ProfilePage from './pages/profile/profile.page.tsx'
import PaymentSuccess from './pages/payment-result/payment-success.page.tsx'
import PaymentCancel from './pages/payment-result/payment-cancel.page.tsx'
import ViewEvent from './pages/view-event/view-event.page.tsx'
import Events from './pages/events/events.page.tsx'
import EventEdit from './pages/add-event/edit-event.page.tsx'

export default function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route
                    path="/dashboard"
                    element={
                        <ProtectedRoute>
                            <Dashboard />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/events/new"
                    element={
                        <ProtectedRoute>
                            <EventCreate />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/events/search"
                    element={
                        <ProtectedRoute>
                            <Events />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/events/:eventId/edit"
                    element={
                        <ProtectedRoute>
                            <EventEdit />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/events/:id"
                    element={
                        <ProtectedRoute>
                            <ViewEvent />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/archive"
                    element={
                        <ProtectedRoute>
                            <ArchivePage />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/profile"
                    element={
                        <ProtectedRoute>
                            <ProfilePage />
                        </ProtectedRoute>
                    }
                />
                <Route path="/payment/success" element={<PaymentSuccess />} />
                <Route path="/payment/cancel" element={<PaymentCancel />} />
            </Routes>
            <ToastContainer />
        </BrowserRouter>
    )
}
