import {
    Container,
    Grid,
    Typography,
    Box,
    useTheme,
    CircularProgress,
} from '@mui/material'
import { useDashboard } from '../../shared/hooks/use-events.hook.ts'
import DefaultLayout from '../../shared/components/default-layout.component.tsx'
import EventCard from '../../shared/components/event-card.component.tsx'
import { Event } from '../../shared/common/interfaces/event.interface.ts'

export default function Dashboard() {
    const theme = useTheme()
    const { data, isLoading, error } = useDashboard()

    if (isLoading)
        return <CircularProgress sx={{ display: 'block', mx: 'auto', my: 4 }} />
    if (error)
        return (
            <Typography color="error" align="center" sx={{ my: 4 }}>
                {error.message}
            </Typography>
        )
    if (!data)
        return (
            <Typography align="center" sx={{ my: 4 }}>
                No data available
            </Typography>
        )

    const { my_events, friends_events, can_edit_events } = data

    const renderEventSection = (
        title: string,
        events: Event[],
        emptyMessage: string,
    ) => (
        <Box sx={{ mb: 4 }}>
            <Typography
                variant="h4"
                sx={{ mb: 2, color: theme.palette.text.primary }}
            >
                {title}
            </Typography>
            {events.length === 0 ? (
                <Typography
                    variant="body1"
                    color="text.secondary"
                    sx={{ mb: 2 }}
                >
                    {emptyMessage}
                </Typography>
            ) : (
                <Grid container spacing={2}>
                    {events.slice(0, 3).map((event) => (
                        <EventCard event={event} />
                    ))}
                </Grid>
            )}
        </Box>
    )

    return (
        <DefaultLayout>
            <Container maxWidth="lg" sx={{ py: 4 }}>
                {renderEventSection(
                    'My Events',
                    my_events,
                    'You have no events created.',
                )}
                {renderEventSection(
                    'Editable Events',
                    can_edit_events,
                    'No events you can edit.',
                )}
                {renderEventSection(
                    "Friends' Events",
                    friends_events,
                    "No friends' events available.",
                )}
            </Container>
        </DefaultLayout>
    )
}
