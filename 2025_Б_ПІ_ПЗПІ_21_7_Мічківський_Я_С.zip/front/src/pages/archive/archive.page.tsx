import { Box, Fab, Typography, useTheme } from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import DefaultLayout from '../../shared/components/default-layout.component'
import { useImageGallery } from './hooks/use-image-gallery.hook'
import ImageCard from './components/image-card.component'
import DeleteConfirmationModal from './components/delete-confirmation-modal.component'
import { getDate } from '../../shared/helpers/cloudinary.helper.ts'
import UploadModal from '../../shared/components/upload-modal.component'
import ImageZoomDialog from '../../shared/components/image-zoom-dialog.component'
import StorageIndicator from './components/storage-indicator.component'

export default function ArchivePage() {
    const theme = useTheme()
    const {
        zoomedImage,
        openUploadModal,
        openDeleteModal,
        isDeleting,
        isUploading,
        selectedFile,
        groupedImages,
        storage_size,
        free_space,
        handleZoomImage,
        handleNavigateImage,
        handleOpenUploadModal,
        handleCloseUploadModal,
        handleFileChange,
        handleUploadImage,
        handleOpenDeleteModal,
        handleCloseDeleteModal,
        handleDeleteImage,
    } = useImageGallery()

    const sortedDates = Object.keys(groupedImages).sort((a, b) => {
        const dateA = new Date(a).getTime()
        const dateB = new Date(b).getTime()
        return dateB - dateA
    })

    return (
        <DefaultLayout>
            <Box className="p-6 max-w-[1200px] mx-auto relative">
                {/* Storage Indicator */}
                <StorageIndicator
                    storageSize={storage_size}
                    freeSpace={free_space}
                />

                {/* Add Image Button */}
                <Fab
                    color="primary"
                    onClick={handleOpenUploadModal}
                    sx={{
                        bgcolor: theme.palette.primary.main,
                        position: 'absolute',
                        top: 16,
                        right: 16,
                    }}
                >
                    <AddIcon />
                </Fab>

                {/* Image Groups */}
                {sortedDates.map((date) => (
                    <Box key={date} className="mb-8">
                        <Typography
                            variant="h5"
                            sx={{ color: theme.palette.text.primary }}
                            className="mb-4"
                        >
                            {date}
                        </Typography>
                        <Box className="flex flex-wrap gap-[2px_1px] justify-start">
                            {groupedImages[date]
                                .sort((a, b) => {
                                    const timestampA = new Date(
                                        getDate(a.link),
                                    ).getTime()
                                    const timestampB = new Date(
                                        getDate(b.link),
                                    ).getTime()
                                    return timestampB - timestampA
                                })
                                .map((image) => (
                                    <ImageCard
                                        key={image.id}
                                        image={image}
                                        onZoom={handleZoomImage}
                                        onDelete={handleOpenDeleteModal}
                                    />
                                ))}
                        </Box>
                    </Box>
                ))}

                {/* Modals */}
                <ImageZoomDialog
                    image={zoomedImage}
                    onClose={() => handleZoomImage(null)}
                    onNavigate={handleNavigateImage}
                />
                <UploadModal
                    open={openUploadModal}
                    isUploading={isUploading}
                    selectedFile={selectedFile}
                    onClose={handleCloseUploadModal}
                    onFileChange={handleFileChange}
                    onUpload={handleUploadImage}
                />
                <DeleteConfirmationModal
                    open={openDeleteModal}
                    isDeleting={isDeleting}
                    onClose={handleCloseDeleteModal}
                    onConfirm={handleDeleteImage}
                />
            </Box>
        </DefaultLayout>
    )
}
