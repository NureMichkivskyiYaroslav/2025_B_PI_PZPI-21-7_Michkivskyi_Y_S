import { Box, IconButton, Tooltip, Typography, useTheme } from '@mui/material'
import DeleteIcon from '@mui/icons-material/Delete'
import { Image } from '../../../shared/common/interfaces/image.interface.ts'
import {
    getDate,
    getThumbnailUrl,
} from '../../../shared/helpers/cloudinary.helper.ts'

interface ImageCardProps {
    image: Image
    onZoom: (image: Image) => void
    onDelete: (id: string) => void
}

export default function ImageCard({ image, onZoom, onDelete }: ImageCardProps) {
    const theme = useTheme()
    const thumbnailUrl = getThumbnailUrl(image.link)

    const tooltipContent = (
        <Box className="p-2 flex max-w-[300px] items-center gap-2">
            <Box>
                <Typography
                    variant="caption"
                    sx={{ color: theme.palette.text.primary }}
                >
                    Date: {getDate(image.link)}
                </Typography>
                <Typography
                    variant="caption"
                    sx={{ color: theme.palette.text.primary }}
                    className="block mb-2"
                >
                    Size: {(image.size / 1024).toFixed(1)} KB
                </Typography>
            </Box>
            <IconButton
                size="small"
                color="error"
                onClick={(e) => {
                    e.stopPropagation()
                    onDelete(image.id)
                }}
                sx={{
                    bgcolor: theme.palette.background.paper,
                    '&:hover': {
                        bgcolor: theme.palette.error.main,
                        color: theme.palette.error.contrastText,
                    },
                }}
            >
                <DeleteIcon fontSize="small" />
            </IconButton>
        </Box>
    )

    return (
        <Box
            className="relative cursor-pointer w-[80px] h-[80px] md:w-[200px] md:h-[200px] overflow-hidden"
            onClick={() => onZoom(image)}
        >
            <Tooltip
                title={tooltipContent}
                placement="top"
                arrow
                slotProps={{
                    popper: {
                        sx: {
                            '& .MuiTooltip-tooltip': {
                                bgcolor: theme.palette.background.paper,
                                boxShadow: theme.shadows[4],
                            },
                            '& .MuiTooltip-arrow': {
                                color: theme.palette.background.paper,
                            },
                        },
                    },
                }}
            >
                <img
                    src={thumbnailUrl}
                    alt="thumbnail"
                    loading="lazy"
                    className="w-full h-full object-cover block"
                />
            </Tooltip>
            <IconButton
                className="absolute top-1 right-1 opacity-0 hover:opacity-100"
                size="small"
                color="error"
                onClick={(e) => {
                    e.stopPropagation()
                    onDelete(image.id)
                }}
                sx={{
                    bgcolor: theme.palette.background.paper,
                    '&:hover': {
                        bgcolor: theme.palette.error.main,
                        color: theme.palette.error.contrastText,
                    },
                }}
            >
                <DeleteIcon fontSize="small" />
            </IconButton>
        </Box>
    )
}
