import {
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Typography,
} from '@mui/material'

interface DeleteConfirmationModalProps {
    open: boolean
    isDeleting: boolean
    onClose: () => void
    onConfirm: () => void
}

export default function DeleteConfirmationModal({
    open,
    isDeleting,
    onClose,
    onConfirm,
}: DeleteConfirmationModalProps) {
    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogContent>
                <Typography>
                    Are you sure you want to delete this image? This action
                    cannot be undone.
                </Typography>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Cancel</Button>
                <Button
                    onClick={onConfirm}
                    color="error"
                    disabled={isDeleting}
                    variant="contained"
                >
                    {isDeleting ? (
                        <CircularProgress size={24} color="inherit" />
                    ) : (
                        'Delete'
                    )}
                </Button>
            </DialogActions>
        </Dialog>
    )
}
