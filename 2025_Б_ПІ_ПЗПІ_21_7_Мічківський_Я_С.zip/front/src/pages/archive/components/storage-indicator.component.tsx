import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    LinearProgress,
    TextField,
    Typography,
    useTheme,
} from '@mui/material'
import { useState } from 'react'
import { Add, Remove } from '@mui/icons-material'
import { usePayment } from '../../../shared/hooks/use-payment.hook'

interface StorageIndicatorProps {
    storageSize: number // in bytes
    freeSpace: number // in bytes
}

export default function StorageIndicator({
    storageSize,
    freeSpace,
}: StorageIndicatorProps) {
    console.log(storageSize)
    console.log(freeSpace)
    const theme = useTheme()
    const { createPayment, isCreatingPayment } = usePayment()
    const [openPurchaseModal, setOpenPurchaseModal] = useState(false)
    const [storageUnits, setStorageUnits] = useState(1)

    const totalStorage = storageSize // Total storage is storageSize
    const usedStorage = (storageSize - freeSpace) / 1e9 // Used storage in GB
    const totalStorageGB = totalStorage / 1e9 // Total storage in GB
    const storagePercentage =
        totalStorageGB > 0 ? (usedStorage / totalStorageGB) * 100 : 0 // Avoid division by zero
    const pricePer200MB = Number(import.meta.env.VITE_PRICE_PER_200MB) || 0.99
    const totalPrice = (storageUnits * pricePer200MB).toFixed(2)
    const additionalStorageMB = storageUnits * 200

    const handleOpenPurchaseModal = () => setOpenPurchaseModal(true)
    const handleClosePurchaseModal = () => setOpenPurchaseModal(false)

    const handleIncrement = () => setStorageUnits((prev) => prev + 1)
    const handleDecrement = () =>
        setStorageUnits((prev) => (prev > 1 ? prev - 1 : 1))

    const handlePurchase = async () => {
        const count = storageUnits * 2 // 200MB = 2 * 100MB units
        await createPayment({ count })
    }

    return (
        <>
            <Box
                sx={{
                    display: 'flex',
                    gap: 2,
                    mb: 4,
                    flexDirection: { xs: 'column', sm: 'row' },
                    alignItems: { xs: 'flex-start', sm: 'center' },
                }}
            >
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                        {usedStorage.toFixed(1)} / {totalStorageGB.toFixed(1)}{' '}
                        GB ({storagePercentage.toFixed(0)}%)
                    </Typography>
                    <LinearProgress
                        variant="determinate"
                        value={storagePercentage}
                        sx={{
                            width: { xs: 80, sm: 100 },
                            bgcolor: theme.palette.grey[300],
                            '& .MuiLinearProgress-bar': {
                                bgcolor: theme.palette.primary.main,
                            },
                        }}
                    />
                </Box>
                <Button
                    variant="contained"
                    color="primary"
                    onClick={handleOpenPurchaseModal}
                    sx={{
                        bgcolor: theme.palette.primary.main,
                        '&:hover': {
                            bgcolor: theme.palette.primary.dark,
                        },
                    }}
                >
                    Buy More Storage
                </Button>
            </Box>

            <Dialog open={openPurchaseModal} onClose={handleClosePurchaseModal}>
                <DialogTitle sx={{ color: theme.palette.text.primary }}>
                    Purchase Additional Storage
                </DialogTitle>
                <DialogContent>
                    <Box
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 2,
                            mb: 2,
                        }}
                    >
                        <IconButton
                            onClick={handleDecrement}
                            disabled={storageUnits === 1}
                        >
                            <Remove />
                        </IconButton>
                        <TextField
                            value={`${additionalStorageMB} MB`}
                            InputProps={{ readOnly: true }}
                            sx={{ width: 120 }}
                        />
                        <IconButton onClick={handleIncrement}>
                            <Add />
                        </IconButton>
                    </Box>
                    <Typography variant="body1" sx={{ mb: 2 }}>
                        Price: ${totalPrice} ({storageUnits} x ${pricePer200MB}{' '}
                        per 200MB)
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={handleClosePurchaseModal}
                        sx={{ color: theme.palette.text.secondary }}
                    >
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        onClick={handlePurchase}
                        disabled={isCreatingPayment}
                        sx={{
                            bgcolor: '#0070BA', // PayPal blue
                            color: '#fff',
                            '&:hover': {
                                bgcolor: '#003087',
                            },
                        }}
                    >
                        Buy with PayPal
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    )
}
