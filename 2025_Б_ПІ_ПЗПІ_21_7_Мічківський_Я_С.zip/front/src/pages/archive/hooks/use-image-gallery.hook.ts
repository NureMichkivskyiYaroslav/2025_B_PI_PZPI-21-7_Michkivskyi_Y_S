import { ChangeEvent, useMemo, useState } from 'react'
import { toast } from 'react-toastify'
import { Image } from '../../../shared/common/interfaces/image.interface'
import { useImages } from '../../../shared/hooks/use-images.hook'

export interface GroupedImages {
    [date: string]: Image[]
}

export interface ImageGalleryState {
    zoomedImage: Image | null
    openUploadModal: boolean
    openDeleteModal: boolean
    deletingImageId: string | null
    isDeleting: boolean
    isUploading: boolean
    selectedFile: File | null
    groupedImages: GroupedImages
    storage_size: number
    free_space: number
    handleZoomImage: (image: Image | null) => void
    handleNavigateImage: (direction: 'prev' | 'next') => void
    handleOpenUploadModal: () => void
    handleCloseUploadModal: () => void
    handleFileChange: (event: ChangeEvent<HTMLInputElement>) => void
    handleUploadImage: (croppedImage: File) => Promise<string | null>
    handleOpenDeleteModal: (id: string) => void
    handleCloseDeleteModal: () => void
    handleDeleteImage: () => Promise<void>
}

export const useImageGallery = (): ImageGalleryState => {
    const {
        images,
        storage_size,
        free_space,
        uploadImageAsync,
        removeImage,
        isUploading,
        isDeleting,
    } = useImages()
    const [zoomedImage, setZoomedImage] = useState<Image | null>(null)
    const [openUploadModal, setOpenUploadModal] = useState(false)
    const [openDeleteModal, setOpenDeleteModal] = useState(false)
    const [deletingImageId, setDeletingImageId] = useState<string | null>(null)
    const [selectedFile, setSelectedFile] = useState<File | null>(null)

    const groupedImages = useMemo(() => {
        const groups: GroupedImages = {}
        images.forEach((image) => {
            const timestamp = image.link.match(/v(\d+)/)?.[1]
            const date = timestamp
                ? new Date(Number(timestamp) * 1000).toLocaleDateString(
                      'en-US',
                      {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                      },
                  )
                : 'Unknown'
            groups[date] = groups[date] || []
            groups[date].push(image)
        })
        return groups
    }, [images])

    const handleZoomImage = (image: Image | null) => {
        setZoomedImage(image)
    }

    const handleNavigateImage = (direction: 'prev' | 'next') => {
        if (!zoomedImage) return
        const allImages = Object.values(groupedImages).flat()
        const currentIndex = allImages.findIndex(
            (img) => img.id === zoomedImage.id,
        )
        if (currentIndex === -1) return

        let newIndex: number
        if (direction === 'prev') {
            newIndex =
                currentIndex > 0 ? currentIndex - 1 : allImages.length - 1
        } else {
            newIndex =
                currentIndex < allImages.length - 1 ? currentIndex + 1 : 0
        }
        setZoomedImage(allImages[newIndex])
    }

    const handleOpenUploadModal = () => {
        setOpenUploadModal(true)
    }

    const handleCloseUploadModal = () => {
        setOpenUploadModal(false)
        setSelectedFile(null)
    }

    const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0]
        if (file && file.type.startsWith('image/')) {
            setSelectedFile(file)
        } else {
            toast.error('Please select a valid image file')
        }
    }

    const handleUploadImage = async (
        croppedImage: File,
    ): Promise<string | null> => {
        if (!croppedImage) return null
        try {
            const response = await uploadImageAsync(croppedImage)
            handleCloseUploadModal()
            return response.id
        } catch {
            // Error handled by toast in useImages
            return null
        }
    }

    const handleOpenDeleteModal = (id: string) => {
        setDeletingImageId(id)
        setOpenDeleteModal(true)
    }

    const handleCloseDeleteModal = () => {
        setDeletingImageId(null)
        setOpenDeleteModal(false)
    }

    const handleDeleteImage = async () => {
        if (!deletingImageId) return
        try {
            await removeImage(deletingImageId)
            if (zoomedImage?.id === deletingImageId) {
                setZoomedImage(null)
            }
            handleCloseDeleteModal()
        } catch {
            // Error handled by toast in useImages
        }
    }

    return {
        zoomedImage,
        openUploadModal,
        openDeleteModal,
        deletingImageId,
        isDeleting,
        isUploading,
        selectedFile,
        groupedImages,
        storage_size,
        free_space,
        handleZoomImage,
        handleNavigateImage,
        handleOpenUploadModal,
        handleCloseUploadModal,
        handleFileChange,
        handleUploadImage,
        handleOpenDeleteModal,
        handleCloseDeleteModal,
        handleDeleteImage,
    }
}
