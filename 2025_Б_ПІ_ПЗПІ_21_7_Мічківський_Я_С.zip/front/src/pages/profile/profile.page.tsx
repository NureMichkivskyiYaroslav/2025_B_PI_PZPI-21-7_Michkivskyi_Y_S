import { Box, Typography, useTheme } from '@mui/material'
import DefaultLayout from '../../shared/components/default-layout.component.tsx'
import ProfileInfo from './components/profile-info/profile-info.component.tsx'
import TagsManager from './components/tags-manager/tags-manager.component.tsx'
import FriendsTabs from './components/friends-tabs/friends-tabs.component.tsx'

export default function ProfilePage() {
    const theme = useTheme()

    return (
        <DefaultLayout>
            <Box sx={{ maxWidth: 800, mx: 'auto', p: { xs: 2, sm: 4 } }}>
                <Typography
                    variant="h4"
                    sx={{
                        color: theme.palette.primary.main,
                        mb: 4,
                        textAlign: 'center',
                        fontWeight: 'bold',
                    }}
                >
                    Your Profile
                </Typography>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                    <ProfileInfo />
                    <TagsManager />
                    <FriendsTabs />
                </Box>
            </Box>
        </DefaultLayout>
    )
}
