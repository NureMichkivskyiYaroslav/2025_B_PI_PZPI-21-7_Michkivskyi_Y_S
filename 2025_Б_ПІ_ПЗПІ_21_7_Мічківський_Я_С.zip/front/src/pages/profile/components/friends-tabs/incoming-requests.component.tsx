import { Box, Typography } from '@mui/material'
import { useTheme } from '@mui/material/styles'
import { FriendListItem } from './friend-list-item.component'
import { Friend } from '../../../../shared/common/interfaces/friend.interface'

interface IncomingRequestsProps {
    incomingRequests: Friend[]
    onAcceptRequest: (friend: Friend) => Promise<void>
    onRejectRequest: (friend: Friend) => Promise<void>
}

export function IncomingRequests({
    incomingRequests,
    onAcceptRequest,
    onRejectRequest,
}: IncomingRequestsProps) {
    const theme = useTheme()

    const handleAction = async (action: () => Promise<void>) => {
        try {
            await action()
        } catch (_) {
            // Error handled by toast in useFriends
        }
    }

    return (
        <Box className="flex flex-col gap-2">
            {incomingRequests.length === 0 ? (
                <Typography sx={{ color: theme.palette.text.secondary }}>
                    No incoming friend requests.
                </Typography>
            ) : (
                incomingRequests.map((request) => (
                    <FriendListItem
                        key={request.user_id}
                        friend={request}
                        handleAction={handleAction}
                        onAcceptRequest={onAcceptRequest}
                        onRejectRequest={onRejectRequest}
                    />
                ))
            )}
        </Box>
    )
}
