import { useState, useEffect, SyntheticEvent } from 'react'
import { useFriends } from '../../../../shared/hooks/use-friends.hook'
import { Friend } from '../../../../shared/common/interfaces/friend.interface'

export function useFriendsTabs() {
    const {
        friends,
        outgoingRequests,
        incomingRequests,
        isLoadingFriends,
        isLoadingOutgoing,
        isLoadingIncoming,
        isLoadingSearch,
        errorFetching,
        errorSearching,
        searchUsers,
        sendFriendRequest,
        acceptFriendRequest,
        rejectFriendRequest,
        deleteFriend,
        fetchFriends,
        fetchOutgoingRequests,
        fetchIncomingRequests,
    } = useFriends()
    const [tabValue, setTabValue] = useState(0)
    const [openSearchModal, setOpenSearchModal] = useState(false)
    const [searchQuery, setSearchQuery] = useState('')
    const [searchResults, setSearchResults] = useState<Friend[]>([])

    useEffect(() => {
        const handler = setTimeout(() => {
            if (searchQuery.replace(/\s/g, '').length >= 2) {
                searchUsers(searchQuery).then((results) => {
                    setSearchResults(results)
                })
            } else {
                setSearchResults([])
            }
        }, 1000)

        return () => clearTimeout(handler)
    }, [searchQuery, searchUsers])

    const refetchAll = async () => {
        await Promise.all([
            fetchFriends(),
            fetchOutgoingRequests(),
            fetchIncomingRequests(),
            searchQuery.replace(/\s/g, '').length >= 2
                ? searchUsers(searchQuery).then(setSearchResults)
                : Promise.resolve(),
        ])
    }

    const handleTabChange = (_event: SyntheticEvent, newValue: number) => {
        setTabValue(newValue)
    }

    const handleOpenSearchModal = () => setOpenSearchModal(true)

    const handleCloseSearchModal = () => {
        setOpenSearchModal(false)
        setSearchQuery('')
        setSearchResults([])
    }

    const handleSendFriendRequest = async (friend: Friend) => {
        await sendFriendRequest(friend)
        await refetchAll()
    }

    const handleAcceptFriendRequest = async (friend: Friend) => {
        await acceptFriendRequest(friend)
        await refetchAll()
    }

    const handleRejectFriendRequest = async (friend: Friend) => {
        await rejectFriendRequest(friend)
        await refetchAll()
    }

    const handleDeleteFriend = async (friend: Friend) => {
        await deleteFriend(friend)
        await refetchAll()
    }

    return {
        tabValue,
        handleTabChange,
        friends,
        outgoingRequests,
        incomingRequests,
        isLoading:
            isLoadingFriends ||
            isLoadingOutgoing ||
            isLoadingIncoming ||
            isLoadingSearch,
        errorFetching,
        errorSearching,
        openSearchModal,
        handleOpenSearchModal,
        handleCloseSearchModal,
        searchQuery,
        setSearchQuery,
        isLoadingSearch,
        searchResults,
        handleSendFriendRequest,
        handleAcceptFriendRequest,
        handleRejectFriendRequest,
        handleDeleteFriend,
    }
}
