import { Box, Typography } from '@mui/material'
import { useTheme } from '@mui/material/styles'
import { FriendListItem } from './friend-list-item.component'
import { Friend } from '../../../../shared/common/interfaces/friend.interface'

interface OutgoingRequestsProps {
    outgoingRequests: Friend[]
    onRejectRequest: (friend: Friend) => Promise<void>
}

export function OutgoingRequests({
    outgoingRequests,
    onRejectRequest,
}: OutgoingRequestsProps) {
    const theme = useTheme()

    const handleAction = async (action: () => Promise<void>) => {
        try {
            await action()
        } catch (_) {
            // Error handled by toast in useFriends
        }
    }

    return (
        <Box className="flex flex-col gap-2">
            {outgoingRequests.length === 0 ? (
                <Typography sx={{ color: theme.palette.text.secondary }}>
                    No outgoing friend requests.
                </Typography>
            ) : (
                outgoingRequests.map((request) => (
                    <FriendListItem
                        key={request.user_id}
                        friend={request}
                        handleAction={handleAction}
                        onRejectRequest={onRejectRequest}
                    />
                ))
            )}
        </Box>
    )
}
