import { Box, IconButton, Tooltip, Typography } from '@mui/material'
import {
    HourglassEmpty,
    CheckCircle,
    Check,
    Close,
    PersonRemove,
} from '@mui/icons-material'
import { PersonAdd as FriendPersonAddIcon } from '@mui/icons-material'
import { useTheme } from '@mui/material/styles'
import { alpha } from '@mui/material'
import { Friend } from '../../../../shared/common/interfaces/friend.interface'

interface FriendListItemProps {
    friend: Friend
    handleAction: (action: () => Promise<void>) => Promise<void>
    onSendRequest?: (friend: Friend) => Promise<void>
    onAcceptRequest?: (friend: Friend) => Promise<void>
    onRejectRequest?: (friend: Friend) => Promise<void>
    onDeleteFriend?: (friend: Friend) => Promise<void>
}

export function FriendListItem({
    friend,
    handleAction,
    onSendRequest,
    onAcceptRequest,
    onRejectRequest,
    onDeleteFriend,
}: FriendListItemProps) {
    const theme = useTheme()

    return (
        <Box
            className="h-10 flex items-center justify-between p-2 rounded-md w-full"
            sx={{
                bgcolor: alpha(theme.palette.background.default, 0.3),
                borderBottom: `1px solid ${alpha(theme.palette.divider, 0.3)}`,
                '&:hover': {
                    bgcolor: alpha(theme.palette.background.default, 0.4),
                },
            }}
        >
            <Typography sx={{ color: theme.palette.text.primary }}>
                {friend.user_name}
            </Typography>
            <Box className="flex items-center gap-2">
                {friend.friend_status === 'pending' && onRejectRequest && (
                    <Tooltip title="Cancel Request">
                        <IconButton
                            onClick={() =>
                                handleAction(() => onRejectRequest(friend))
                            }
                            sx={{ color: theme.palette.text.secondary }}
                        >
                            <HourglassEmpty />
                        </IconButton>
                    </Tooltip>
                )}
                {friend.friend_status === 'incoming' &&
                    onAcceptRequest &&
                    onRejectRequest && (
                        <>
                            <Tooltip title="Accept Request">
                                <IconButton
                                    onClick={() =>
                                        handleAction(() =>
                                            onAcceptRequest(friend),
                                        )
                                    }
                                    sx={{ color: theme.palette.text.secondary }}
                                >
                                    <Check />
                                </IconButton>
                            </Tooltip>
                            <Tooltip title="Decline Request">
                                <IconButton
                                    onClick={() =>
                                        handleAction(() =>
                                            onRejectRequest(friend),
                                        )
                                    }
                                    sx={{ color: theme.palette.text.secondary }}
                                >
                                    <Close />
                                </IconButton>
                            </Tooltip>
                        </>
                    )}
                {friend.friend_status === '' && onSendRequest && (
                    <Tooltip title="Add Friend">
                        <IconButton
                            onClick={() =>
                                handleAction(() => onSendRequest(friend))
                            }
                            sx={{ color: theme.palette.text.secondary }}
                        >
                            <FriendPersonAddIcon />
                        </IconButton>
                    </Tooltip>
                )}
                {friend.friend_status === 'accepted' && onDeleteFriend && (
                    <>
                        <Tooltip title="Friend Accepted">
                            <IconButton
                                disabled
                                sx={{ color: theme.palette.success.main }}
                            >
                                <CheckCircle />
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="Remove Friend">
                            <IconButton
                                onClick={() =>
                                    handleAction(() => onDeleteFriend(friend))
                                }
                                sx={{ color: theme.palette.text.secondary }}
                            >
                                <PersonRemove />
                            </IconButton>
                        </Tooltip>
                    </>
                )}
            </Box>
        </Box>
    )
}
