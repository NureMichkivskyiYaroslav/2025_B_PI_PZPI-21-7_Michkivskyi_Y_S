import { Box, Typography } from '@mui/material'
import { useTheme } from '@mui/material/styles'
import { FriendListItem } from './friend-list-item.component'
import { Friend } from '../../../../shared/common/interfaces/friend.interface'

interface FriendsListProps {
    friends: Friend[]
    onDeleteFriend: (friend: Friend) => Promise<void>
}

export function FriendsList({ friends, onDeleteFriend }: FriendsListProps) {
    const theme = useTheme()

    const handleAction = async (action: () => Promise<void>) => {
        try {
            await action()
        } catch (_) {
            // Error handled by toast in useFriends
        }
    }

    return (
        <Box className="flex flex-col gap-2">
            {friends.length === 0 ? (
                <Typography sx={{ color: theme.palette.text.secondary }}>
                    No friends yet.
                </Typography>
            ) : (
                friends.map((friend) => (
                    <FriendListItem
                        key={friend.user_id}
                        friend={friend}
                        handleAction={handleAction}
                        onDeleteFriend={onDeleteFriend}
                    />
                ))
            )}
        </Box>
    )
}
