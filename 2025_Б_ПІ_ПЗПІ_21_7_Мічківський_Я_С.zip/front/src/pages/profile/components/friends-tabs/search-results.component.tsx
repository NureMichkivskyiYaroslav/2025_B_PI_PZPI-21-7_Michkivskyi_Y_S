import { Box, CircularProgress, Typography } from '@mui/material'
import { useState, useEffect } from 'react'
import { useTheme } from '@mui/material/styles'
import { FriendListItem } from './friend-list-item.component'
import { Friend } from '../../../../shared/common/interfaces/friend.interface'

interface SearchResultsProps {
    results: Friend[]
    searchQuery: string
    isLoadingSearch: boolean
    onSendRequest: (friend: Friend) => Promise<void>
    onAcceptRequest: (friend: Friend) => Promise<void>
    onRejectRequest: (friend: Friend) => Promise<void>
    onDeleteFriend: (friend: Friend) => Promise<void>
}

export function SearchResults({
    results,
    searchQuery,
    isLoadingSearch,
    onSendRequest,
    onAcceptRequest,
    onRejectRequest,
    onDeleteFriend,
}: SearchResultsProps) {
    const theme = useTheme()
    const hasValidQuery = searchQuery.replace(/\s/g, '').length >= 2
    const [localResults, setLocalResults] = useState<Friend[]>(results)

    useEffect(() => {
        setLocalResults(results)
    }, [results])

    const handleAction = async (action: () => Promise<void>) => {
        try {
            await action()
        } catch (_) {
            // Error handled by toast in useFriends
        }
    }

    return (
        <Box
            className="h-48 overflow-y-auto rounded p-2 flex flex-col items-start justify-start"
            sx={{ bgcolor: theme.palette.background.paper }}
        >
            {isLoadingSearch ? (
                <CircularProgress
                    size={24}
                    sx={{ color: theme.palette.text.secondary }}
                />
            ) : !hasValidQuery ? (
                <Typography sx={{ color: theme.palette.text.secondary }}>
                    Enter at least 2 letters
                </Typography>
            ) : localResults.length === 0 ? (
                <Typography sx={{ color: theme.palette.text.secondary }}>
                    No users found
                </Typography>
            ) : (
                localResults.map((result) => (
                    <FriendListItem
                        key={result.user_id}
                        friend={result}
                        handleAction={handleAction}
                        onSendRequest={onSendRequest}
                        onAcceptRequest={onAcceptRequest}
                        onRejectRequest={onRejectRequest}
                        onDeleteFriend={onDeleteFriend}
                    />
                ))
            )}
        </Box>
    )
}
