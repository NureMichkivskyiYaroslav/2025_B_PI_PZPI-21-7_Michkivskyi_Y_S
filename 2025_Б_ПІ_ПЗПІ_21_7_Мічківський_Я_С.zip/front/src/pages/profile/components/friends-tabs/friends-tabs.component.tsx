import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Tab,
    Tabs,
    TextField,
    Typography,
} from '@mui/material'
import { useTheme } from '@mui/material/styles'
import { useFriendsTabs } from './use-friends-tab.hook'
import { FriendsList } from './friends-list.component'
import { OutgoingRequests } from './outgoing-requests.component'
import { IncomingRequests } from './incoming-requests.component'
import { SearchResults } from './search-results.component'

export default function FriendsTabs() {
    const theme = useTheme()
    const {
        tabValue,
        handleTabChange,
        friends,
        outgoingRequests,
        incomingRequests,
        isLoading,
        errorFetching,
        errorSearching,
        openSearchModal,
        handleOpenSearchModal,
        handleCloseSearchModal,
        searchQuery,
        setSearchQuery,
        isLoadingSearch,
        searchResults,
        handleSendFriendRequest,
        handleAcceptFriendRequest,
        handleRejectFriendRequest,
        handleDeleteFriend,
    } = useFriendsTabs()

    return (
        <Box
            className="p-6 rounded-lg"
            sx={{
                bgcolor: theme.palette.background.paper,
                boxShadow: theme.shadows[4],
            }}
        >
            <Box className="flex justify-between items-center mb-4">
                <Typography
                    variant="h6"
                    sx={{
                        fontWeight: 'bold',
                        fontSize: '1.125rem',
                        color: theme.palette.text.primary,
                    }}
                >
                    Friends
                </Typography>
                <Button
                    variant="contained"
                    onClick={handleOpenSearchModal}
                    sx={{
                        bgcolor: theme.palette.primary.main,
                        '&:hover': { bgcolor: theme.palette.primary.dark },
                        color: theme.palette.primary.contrastText,
                    }}
                >
                    Search Friends
                </Button>
            </Box>
            <Tabs
                value={tabValue}
                onChange={handleTabChange}
                className="mb-4"
                sx={{ '& .MuiTab-root': { textTransform: 'none' } }}
            >
                <Tab label="My Friends" />
                <Tab label="My Invitations" />
                <Tab label="Invitations to Me" />
            </Tabs>
            {isLoading && (
                <Typography sx={{ color: theme.palette.text.primary }}>
                    Loading...
                </Typography>
            )}
            {errorFetching && (
                <Typography sx={{ color: theme.palette.error.main }}>
                    {errorFetching.message}
                </Typography>
            )}
            {tabValue === 0 && (
                <FriendsList
                    friends={friends}
                    onDeleteFriend={handleDeleteFriend}
                />
            )}
            {tabValue === 1 && (
                <OutgoingRequests
                    outgoingRequests={outgoingRequests}
                    onRejectRequest={handleRejectFriendRequest}
                />
            )}
            {tabValue === 2 && (
                <IncomingRequests
                    incomingRequests={incomingRequests}
                    onAcceptRequest={handleAcceptFriendRequest}
                    onRejectRequest={handleRejectFriendRequest}
                />
            )}
            <Dialog
                open={openSearchModal}
                onClose={handleCloseSearchModal}
                sx={{ '& .MuiDialog-paper': { width: '640px' } }}
            >
                <DialogTitle sx={{ color: theme.palette.text.primary }}>
                    Search Users
                </DialogTitle>
                <DialogContent>
                    <TextField
                        label="Search by name"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        fullWidth
                        className="mb-4"
                        sx={{
                            '& .MuiInputLabel-root': {
                                color: theme.palette.text.secondary,
                            },
                            '& .MuiOutlinedInput-root': {
                                '& fieldset': {
                                    borderColor: theme.palette.text.secondary,
                                },
                                '&:hover fieldset': {
                                    borderColor: theme.palette.primary.main,
                                },
                            },
                        }}
                    />
                    {errorSearching && (
                        <Typography
                            sx={{ color: theme.palette.error.main, mb: 2 }}
                        >
                            {errorSearching.message}
                        </Typography>
                    )}
                    <SearchResults
                        results={searchResults}
                        searchQuery={searchQuery}
                        isLoadingSearch={isLoadingSearch}
                        onSendRequest={handleSendFriendRequest}
                        onAcceptRequest={handleAcceptFriendRequest}
                        onRejectRequest={handleRejectFriendRequest}
                        onDeleteFriend={handleDeleteFriend}
                    />
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={handleCloseSearchModal}
                        sx={{ color: theme.palette.text.secondary }}
                    >
                        Cancel
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    )
}
