import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Typography,
    useTheme,
} from '@mui/material'
import { useState } from 'react'
import { useProfileInfo } from './use-profile-info.hook.ts'
import { useAuth } from '../../../../shared/hooks/use-auth.hook.ts'

export default function ProfileInfo() {
    const theme = useTheme()
    const { profile, isLoading, error } = useProfileInfo()
    const { logout } = useAuth()
    const [openLogoutDialog, setOpenLogoutDialog] = useState(false)

    const handleOpenLogoutDialog = () => {
        setOpenLogoutDialog(true)
    }

    const handleCloseLogoutDialog = () => {
        setOpenLogoutDialog(false)
    }

    const handleConfirmLogout = () => {
        logout()
        setOpenLogoutDialog(false)
    }

    if (isLoading) {
        return <Typography>Loading...</Typography>
    }

    if (error) {
        return <Typography color="error">{error}</Typography>
    }

    if (!profile) {
        return <Typography>No profile data available.</Typography>
    }

    const formattedDate = profile.created_at
        ? new Date(profile.created_at).toLocaleString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
              hour: 'numeric',
              minute: 'numeric',
              hour12: true,
          })
        : 'Not set'

    return (
        <Box
            sx={{
                p: 3,
                borderRadius: 8,
                bgcolor: theme.palette.background.paper,
                boxShadow: theme.shadows[1],
            }}
        >
            <Typography
                variant="h6"
                sx={{
                    color: theme.palette.text.primary,
                    mb: 2,
                    fontWeight: 'bold',
                    fontSize: '1.25rem',
                }}
            >
                Profile Information
            </Typography>
            <Typography
                variant="body1"
                sx={{ color: theme.palette.text.primary, mb: 1 }}
            >
                Name: {profile.name || 'Not set'}
            </Typography>
            <Typography
                variant="body1"
                sx={{ color: theme.palette.text.primary, mb: 1 }}
            >
                Email: {profile.email || 'Not set'}
            </Typography>
            <Typography
                variant="body1"
                sx={{ color: theme.palette.text.primary, mb: 2 }}
            >
                Registered: {formattedDate}
            </Typography>
            <Button
                variant="contained"
                onClick={handleOpenLogoutDialog}
                sx={{
                    bgcolor: theme.palette.primary.main,
                    '&:hover': {
                        bgcolor: theme.palette.primary.dark,
                    },
                }}
            >
                Logout
            </Button>
            <Dialog open={openLogoutDialog} onClose={handleCloseLogoutDialog}>
                <DialogTitle>Confirm Logout</DialogTitle>
                <DialogContent>
                    <Typography>Are you sure you want to log out?</Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseLogoutDialog}>Cancel</Button>
                    <Button
                        onClick={handleConfirmLogout}
                        variant="contained"
                        sx={{
                            bgcolor: theme.palette.primary.main,
                            '&:hover': {
                                bgcolor: theme.palette.primary.dark,
                            },
                        }}
                    >
                        Confirm
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    )
}
