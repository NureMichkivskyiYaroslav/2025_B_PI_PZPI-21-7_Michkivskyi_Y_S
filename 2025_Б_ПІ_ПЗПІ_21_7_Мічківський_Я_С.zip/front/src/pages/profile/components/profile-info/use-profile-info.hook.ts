import { useProfile } from '../../../../shared/hooks/use-profile.hook.ts'

export function useProfileInfo() {
    const { profile, isLoadingProfile, error } = useProfile()

    return {
        profile,
        isLoading: isLoadingProfile,
        error,
    }
}
