import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    TextField,
    Typography,
    useTheme,
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { useTagsManager } from './use-tags-manager.hook.ts'

export default function TagsManager() {
    const theme = useTheme()
    const {
        filteredTags,
        isLoading,
        error,
        searchQuery,
        setSearchQuery,
        newTagName,
        setNewTagName,
        openCreateDialog,
        handleOpenCreateDialog,
        handleCloseCreateDialog,
        handleCreateTag,
        handleRequestDelete,
        openConfirmDialog,
        handleConfirmDelete,
        handleCancelDelete,
    } = useTagsManager()

    if (isLoading) {
        return <Typography>Loading tags...</Typography>
    }

    if (error) {
        return <Typography color="error">{error}</Typography>
    }

    return (
        <Box
            sx={{
                p: 3,
                borderRadius: 2,
                bgcolor: 'background.paper',
                boxShadow: theme.shadows[1],
            }}
        >
            <Typography
                variant="h6"
                sx={{
                    color: theme.palette.text.primary,
                    mb: 2,
                    fontWeight: 'bold',
                    fontSize: '1.25rem',
                }}
            >
                Manage Tags
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
                <TextField
                    label="Search Tags"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    sx={{ width: '200px' }}
                />
                <Button
                    variant="contained"
                    onClick={handleOpenCreateDialog}
                    sx={{
                        width: '120px',
                        bgcolor: theme.palette.primary.main,
                        '&:hover': {
                            bgcolor: theme.palette.primary.dark,
                        },
                    }}
                >
                    Add Tag
                </Button>
            </Box>
            {filteredTags.length === 0 ? (
                <Typography color="text.secondary">
                    No tags available.
                </Typography>
            ) : (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {filteredTags.map((tag) => (
                        <Box
                            key={tag.id}
                            sx={{
                                display: 'flex',
                                alignItems: 'center',
                                bgcolor: theme.palette.tag.main,
                                color: theme.palette.tag.contrastText,
                                p: '4px 8px',
                                borderRadius: 1,
                                fontSize: '0.875rem',
                            }}
                        >
                            <Typography sx={{ mr: 1 }}>{tag.name}</Typography>
                            <CloseIcon
                                sx={{
                                    fontSize: '16px',
                                    cursor: 'pointer',
                                    '&:hover': {
                                        opacity: 0.8,
                                    },
                                }}
                                onClick={() => handleRequestDelete(tag.id)}
                            />
                        </Box>
                    ))}
                </Box>
            )}
            <Dialog open={openCreateDialog} onClose={handleCloseCreateDialog}>
                <DialogTitle>Add New Tag</DialogTitle>
                <DialogContent>
                    <TextField
                        label="Tag Name"
                        value={newTagName}
                        onChange={(e) => setNewTagName(e.target.value)}
                        fullWidth
                        sx={{ mt: 1 }}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseCreateDialog}>Cancel</Button>
                    <Button
                        onClick={handleCreateTag}
                        variant="contained"
                        sx={{ bgcolor: theme.palette.primary.main }}
                        disabled={!newTagName.trim()}
                    >
                        Create
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog open={openConfirmDialog} onClose={handleCancelDelete}>
                <DialogTitle>Confirm Tag Deletion</DialogTitle>
                <DialogContent>
                    <Typography>
                        Are you sure you want to delete this tag? It will be
                        removed from all events where it is used.
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCancelDelete}>Cancel</Button>
                    <Button
                        onClick={handleConfirmDelete}
                        variant="contained"
                        sx={{ bgcolor: theme.palette.primary.main }}
                    >
                        Confirm
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    )
}
