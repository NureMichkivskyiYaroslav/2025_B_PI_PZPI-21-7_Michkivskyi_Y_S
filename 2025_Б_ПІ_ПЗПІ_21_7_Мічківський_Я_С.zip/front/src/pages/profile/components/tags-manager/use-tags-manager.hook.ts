import { useState, useMemo } from 'react'
import { useTags } from '../../../../shared/hooks/use-tags.hook.ts'
import { Tag } from '../../../../shared/common/interfaces/tag.interface.ts'

export function useTagsManager() {
    const {
        tags,
        isLoadingTags,
        error,
        createTag,
        isCreatingTag,
        deleteTag,
        isDeletingTag,
    } = useTags()
    const [searchQuery, setSearchQuery] = useState('')
    const [newTagName, setNewTagName] = useState('')
    const [deleteTagId, setDeleteTagId] = useState<string | null>(null)
    const [openCreateDialog, setOpenCreateDialog] = useState(false)
    const [openConfirmDialog, setOpenConfirmDialog] = useState(false)

    const filteredTags = useMemo(() => {
        if (!searchQuery.trim()) return tags
        return tags.filter((tag: Tag) =>
            tag.name.toLowerCase().includes(searchQuery.toLowerCase()),
        )
    }, [tags, searchQuery])

    const handleOpenCreateDialog = () => {
        setOpenCreateDialog(true)
    }

    const handleCloseCreateDialog = () => {
        setOpenCreateDialog(false)
        setNewTagName('')
    }

    const handleCreateTag = () => {
        if (newTagName.trim()) {
            createTag({ name: newTagName })
            setNewTagName('')
            setOpenCreateDialog(false)
        }
    }

    const handleRequestDelete = (id: string) => {
        setDeleteTagId(id)
        setOpenConfirmDialog(true)
    }

    const handleConfirmDelete = () => {
        if (deleteTagId) {
            deleteTag(deleteTagId)
        }
        setOpenConfirmDialog(false)
        setDeleteTagId(null)
    }

    const handleCancelDelete = () => {
        setOpenConfirmDialog(false)
        setDeleteTagId(null)
    }

    return {
        tags,
        filteredTags,
        isLoading: isLoadingTags || isCreatingTag || isDeletingTag,
        error,
        searchQuery,
        setSearchQuery,
        newTagName,
        setNewTagName,
        openCreateDialog,
        handleOpenCreateDialog,
        handleCloseCreateDialog,
        handleCreateTag,
        handleRequestDelete,
        openConfirmDialog,
        handleConfirmDelete,
        handleCancelDelete,
    }
}
