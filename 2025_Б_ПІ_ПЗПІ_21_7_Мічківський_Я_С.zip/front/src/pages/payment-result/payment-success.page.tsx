import { Box, Button, Typography, useTheme } from '@mui/material'
import DefaultLayout from '../../shared/components/default-layout.component'
import { Link } from 'react-router-dom'

export default function PaymentSuccess() {
    const theme = useTheme()

    return (
        <DefaultLayout>
            <Box
                className="p-6 max-w-[1200px] mx-auto"
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 2,
                }}
            >
                <Typography
                    variant="h4"
                    sx={{ color: theme.palette.text.primary, mb: 2 }}
                >
                    Payment Successful!
                </Typography>
                <Typography
                    variant="body1"
                    sx={{ color: theme.palette.text.secondary, mb: 4 }}
                >
                    Your storage has been updated. Thank you for your purchase.
                </Typography>
                <Button
                    component={Link}
                    to="/archive"
                    variant="contained"
                    color="primary"
                    sx={{
                        bgcolor: theme.palette.primary.main,
                        '&:hover': {
                            bgcolor: theme.palette.primary.dark,
                        },
                    }}
                >
                    Back to Archive
                </Button>
            </Box>
        </DefaultLayout>
    )
}
