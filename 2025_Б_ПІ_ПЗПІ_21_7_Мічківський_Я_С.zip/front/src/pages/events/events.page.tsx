import { useState } from 'react'
import {
    Container,
    Grid,
    Typography,
    Box,
    TextField,
    Button,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    useTheme,
    CircularProgress,
} from '@mui/material'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { Dayjs } from 'dayjs'
import DefaultLayout from '../../shared/components/default-layout.component.tsx'
import EventCard from '../../shared/components/event-card.component.tsx'
import { useEvents, useDashboard } from '../../shared/hooks/use-events.hook.ts'
import { Event } from '../../shared/common/interfaces/event.interface.ts'
import { Tag } from '../../shared/common/interfaces/tag.interface.ts'

export default function Events() {
    const theme = useTheme()
    const { fetchEvents } = useEvents()
    const { data: dashboardData } = useDashboard()
    const [name, setName] = useState('')
    const [afterDate, setAfterDate] = useState<Dayjs | null>(null)
    const [beforeDate, setBeforeDate] = useState<Dayjs | null>(null)
    const [selectedTags, setSelectedTags] = useState<string[]>([])
    const [events, setEvents] = useState<Event[]>([])
    const [isLoading, setIsLoading] = useState(false)
    const [error, setError] = useState<string | null>(null)
    
    const tags: Tag[] =
        dashboardData?.my_events
            .concat(dashboardData.friends_events, dashboardData.can_edit_events)
            .flatMap((event) => event.tag_objects || [])
            .filter(
                (tag, index, self) =>
                    tag && self.findIndex((t) => t?.id === tag.id) === index,
            ) || []

    const handleSearch = async () => {
        setIsLoading(true)
        setError(null)
        try {
            const params = {
                name: name.trim() || undefined,
                after_date: afterDate
                    ? afterDate.format('YYYY-MM-DD')
                    : undefined,
                before_date: beforeDate
                    ? beforeDate.format('YYYY-MM-DD')
                    : undefined,
                tags: selectedTags.length > 0 ? selectedTags : undefined,
            }
            const result = await fetchEvents(params)
            setEvents(result)
        } catch (err) {
            setError((err as Error).message || 'Failed to fetch events')
            setEvents([])
        } finally {
            setIsLoading(false)
        }
    }

    return (
        <DefaultLayout>
            <Container maxWidth="lg" sx={{ py: 4 }}>
                <Typography
                    variant="h4"
                    sx={{ mb: 3, color: theme.palette.text.primary }}
                >
                    Search Events
                </Typography>
                <Box
                    sx={{
                        mb: 4,
                        display: 'flex',
                        flexDirection: { xs: 'column', sm: 'row' },
                        gap: 2,
                        alignItems: { sm: 'flex-end' },
                    }}
                >
                    <TextField
                        label="Event Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        variant="outlined"
                        sx={{ flex: 1 }}
                    />
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                            label="After Date"
                            value={afterDate}
                            onChange={(newValue) => setAfterDate(newValue)}
                            slotProps={{ textField: { variant: 'outlined' } }}
                            sx={{ width: { xs: '100%', sm: 200 } }}
                        />
                        <DatePicker
                            label="Before Date"
                            value={beforeDate}
                            onChange={(newValue) => setBeforeDate(newValue)}
                            slotProps={{ textField: { variant: 'outlined' } }}
                            sx={{ width: { xs: '100%', sm: 200 } }}
                        />
                    </LocalizationProvider>
                    <FormControl sx={{ width: { xs: '100%', sm: 200 } }}>
                        <InputLabel>Tags</InputLabel>
                        <Select
                            multiple
                            value={selectedTags}
                            onChange={(e) =>
                                setSelectedTags(e.target.value as string[])
                            }
                            renderValue={(selected) =>
                                tags
                                    .filter((tag) => selected.includes(tag.id))
                                    .map((tag) => tag.name)
                                    .join(', ')
                            }
                        >
                            {tags.map((tag) => (
                                <MenuItem key={tag.id} value={tag.id}>
                                    {tag.name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <Button
                        variant="contained"
                        onClick={handleSearch}
                        sx={{ height: 'fit-content', px: 4 }}
                    >
                        Search
                    </Button>
                </Box>
                {isLoading ? (
                    <CircularProgress
                        sx={{ display: 'block', mx: 'auto', my: 4 }}
                    />
                ) : error ? (
                    <Typography color="error" align="center" sx={{ my: 4 }}>
                        {error}
                    </Typography>
                ) : events.length === 0 ? (
                    <Typography
                        align="center"
                        sx={{ my: 4, color: theme.palette.text.secondary }}
                    >
                        No events found
                    </Typography>
                ) : (
                    <Grid container spacing={2}>
                        {events.map((event) => (
                            <EventCard event={event} />
                        ))}
                    </Grid>
                )}
            </Container>
        </DefaultLayout>
    )
}
