import { Form, Formik } from 'formik'
import {
    Box,
    Button,
    Divider,
    Typography,
    useTheme,
    CircularProgress,
} from '@mui/material'
import { useParams, useNavigate } from 'react-router-dom'
import DefaultLayout from '../../shared/components/default-layout.component'
import EventDetails from './components/event-details.component.tsx'
import TagSelector from './components/tags-tool/tag-selector.component.tsx'
import ImageSelector from './components/image-selector.component.tsx'
import EventDescriptionEditor from './components/event-description-editor.component.tsx'
import ArchiveSelectModal from './components/archive-select-modal.component.tsx'
import { useState } from 'react'
import { useImageGallery } from '../archive/hooks/use-image-gallery.hook.ts'
import UploadModal from '../../shared/components/upload-modal.component.tsx'
import {
    useEvents,
    useEvent,
    EventFormValues,
} from '../../shared/hooks/use-events.hook.ts'
import { eventValidationSchema } from './event-validation.schema.ts'
import dayjs from 'dayjs'
import utc from 'dayjs/plugin/utc'

dayjs.extend(utc)

// Функция для нормализации даты
const normalizeDate = (dateString: string): string => {
    const date = dayjs(dateString)
    return date.isValid() ? date.utc().format('YYYY-MM-DDTHH:mm:ss') + 'Z' : ''
}

export default function EventEdit() {
    const theme = useTheme()
    const navigate = useNavigate()
    const { eventId } = useParams<{ eventId: string }>()
    const { data: event, isLoading, error } = useEvent(eventId!)
    const [openArchiveModal, setOpenArchiveModal] = useState(false)
    const [openUploadModal, setOpenUploadModal] = useState(false)
    const [selectedFile, setSelectedFile] = useState<File | null>(null)
    const [submitAttempted, setSubmitAttempted] = useState(false)
    const { updateEvent, isUpdatingEvent } = useEvents()
    const { isUploading, handleFileChange, handleUploadImage } =
        useImageGallery()

    const handleOpenArchiveModal = (event: React.MouseEvent) => {
        event.preventDefault()
        event.stopPropagation()
        setOpenArchiveModal(true)
    }
    const handleCloseArchiveModal = () => setOpenArchiveModal(false)
    const handleOpenUploadModal = (event: React.MouseEvent) => {
        event.preventDefault()
        event.stopPropagation()
        setOpenUploadModal(true)
    }
    const handleCloseUploadModal = () => {
        setOpenUploadModal(false)
        setSelectedFile(null)
    }

    if (isLoading) {
        return <CircularProgress sx={{ display: 'block', mx: 'auto', my: 4 }} />
    }
    if (error || !event) {
        return (
            <Typography color="error" align="center" sx={{ my: 4 }}>
                {error ? error.message : 'Event not found'}
            </Typography>
        )
    }

    return (
        <DefaultLayout>
            <Box sx={{ maxWidth: 'lg', mx: 'auto', p: { xs: 2, sm: 4 } }}>
                <Typography
                    variant="h4"
                    sx={{
                        color: theme.palette.primary.main,
                        mb: 4,
                        textAlign: 'center',
                        fontWeight: 'bold',
                    }}
                >
                    Edit Event
                </Typography>
                <Formik<EventFormValues>
                    enableReinitialize={false}
                    initialValues={{
                        name: event.name,
                        description: event.description,
                        date: normalizeDate(event.date),
                        status: event.status,
                        tags: event.tags || [],
                        is_comments_allowed: event.is_comments_allowed,
                        image_ids: event.image_ids || [],
                        is_public: event.is_public,
                    }}
                    validationSchema={eventValidationSchema}
                    onSubmit={(values) => {
                        setSubmitAttempted(true)
                        const uniqueImageIds = [...new Set(values.image_ids)]
                        updateEvent({
                            eventId: eventId!,
                            values: { ...values, image_ids: uniqueImageIds },
                        })
                    }}
                >
                    {({
                        values,
                        setFieldValue,
                        errors,
                        touched,
                        isValid,
                        handleSubmit,
                    }) => (
                        <Form noValidate onSubmit={handleSubmit}>
                            {submitAttempted && !isValid && (
                                <Box sx={{ mb: 2 }}>
                                    <Typography color="error" variant="body1">
                                        Please fix the following errors:
                                    </Typography>
                                    <ul
                                        style={{
                                            color: theme.palette.error.main,
                                            marginTop: 8,
                                        }}
                                    >
                                        {Object.entries(errors).map(
                                            ([field, error]) => (
                                                <li key={field}>
                                                    <Typography variant="body2">
                                                        {error}
                                                    </Typography>
                                                </li>
                                            ),
                                        )}
                                    </ul>
                                </Box>
                            )}
                            <Box
                                sx={{
                                    display: 'flex',
                                    flexDirection: { xs: 'column', sm: 'row' },
                                    gap: 4,
                                    alignItems: 'flex-start',
                                    mb: 3,
                                }}
                            >
                                <Box sx={{ width: { xs: '100%', sm: 'auto' } }}>
                                    <Typography
                                        variant="h6"
                                        sx={{
                                            color: theme.palette.text.primary,
                                            mb: 1,
                                            fontWeight: 'bold',
                                            fontSize: '1.25rem',
                                        }}
                                    >
                                        Event Details
                                    </Typography>
                                    <EventDetails
                                        name={values.name}
                                        status={values.status}
                                        date={values.date}
                                        isPublic={values.is_public}
                                        isCommentsAllowed={
                                            values.is_comments_allowed
                                        }
                                        setFieldValue={setFieldValue}
                                        errors={errors}
                                        touched={touched}
                                    />
                                </Box>
                                <Box
                                    sx={{
                                        width: { xs: '100%', sm: 'auto' },
                                        flexGrow: 1,
                                    }}
                                >
                                    <TagSelector
                                        value={values.tags}
                                        onChange={(tags) =>
                                            setFieldValue('tags', tags)
                                        }
                                    />
                                    <Divider
                                        sx={{
                                            my: 2,
                                            borderColor: theme.palette.divider,
                                        }}
                                    />
                                    <ImageSelector
                                        value={values.image_ids}
                                        onChange={(ids) =>
                                            setFieldValue('image_ids', ids)
                                        }
                                        onOpenArchive={handleOpenArchiveModal}
                                        onOpenUpload={handleOpenUploadModal}
                                    />
                                </Box>
                            </Box>
                            <Divider
                                sx={{
                                    my: 2,
                                    borderColor: theme.palette.divider,
                                }}
                            />
                            <Box
                                sx={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: 3,
                                    '& > *': 'auto',
                                }}
                            >
                                <Box>
                                    <Typography
                                        variant="h6"
                                        sx={{
                                            color: theme.palette.text.primary,
                                            mb: 1,
                                            fontWeight: 'bold',
                                            fontSize: '1.25rem',
                                        }}
                                    >
                                        Description
                                    </Typography>
                                    <EventDescriptionEditor
                                        value={values.description}
                                        onChange={(value) =>
                                            setFieldValue('description', value)
                                        }
                                    />
                                    {touched.description &&
                                        errors.description && (
                                            <Typography
                                                variant="body2"
                                                color="error"
                                                sx={{ mt: 1 }}
                                            >
                                                {errors.description}
                                            </Typography>
                                        )}
                                </Box>
                                <Box
                                    sx={{
                                        display: 'flex',
                                        justifyContent: 'center',
                                        gap: 2,
                                    }}
                                >
                                    <Button
                                        variant="outlined"
                                        onClick={() =>
                                            navigate(`/events/${eventId}`)
                                        }
                                        sx={{
                                            width: '200px',
                                            py: 1.5,
                                            borderColor: theme.palette.divider,
                                            color: theme.palette.text.primary,
                                            '&:hover': {
                                                borderColor:
                                                    theme.palette.primary.main,
                                                backgroundColor:
                                                    theme.palette.action.hover,
                                            },
                                        }}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        type="submit"
                                        variant="contained"
                                        sx={{
                                            width: '200px',
                                            py: 1.5,
                                            bgcolor: theme.palette.primary.main,
                                            '&:hover': {
                                                bgcolor:
                                                    theme.palette.primary.dark,
                                                transform: 'scale(1.02)',
                                                transition:
                                                    'all 0.2s ease-in-out',
                                            },
                                            '&:disabled': {
                                                bgcolor:
                                                    theme.palette.action
                                                        .disabledBackground,
                                            },
                                        }}
                                        disabled={isUpdatingEvent}
                                    >
                                        {isUpdatingEvent
                                            ? 'Updating...'
                                            : 'Update Event'}
                                    </Button>
                                </Box>
                            </Box>
                            <ArchiveSelectModal
                                open={openArchiveModal}
                                onClose={handleCloseArchiveModal}
                                selectedIds={values.image_ids}
                                onSelect={(ids) => {
                                    const uniqueIds = ids.filter(
                                        (id) => !values.image_ids.includes(id),
                                    )
                                    setFieldValue('image_ids', [
                                        ...values.image_ids,
                                        ...uniqueIds,
                                    ])
                                }}
                            />
                            <UploadModal
                                open={openUploadModal}
                                isUploading={isUploading}
                                selectedFile={selectedFile}
                                onClose={handleCloseUploadModal}
                                onFileChange={(e) => {
                                    handleFileChange(e)
                                    setSelectedFile(e.target.files?.[0] || null)
                                }}
                                onUpload={async (croppedImage) => {
                                    const imageId =
                                        await handleUploadImage(croppedImage)
                                    if (
                                        imageId &&
                                        !(
                                            values.image_ids as string[]
                                        ).includes(imageId)
                                    ) {
                                        setFieldValue('image_ids', [
                                            ...values.image_ids,
                                            imageId,
                                        ])
                                    }
                                    handleCloseUploadModal()
                                }}
                            />
                        </Form>
                    )}
                </Formik>
            </Box>
        </DefaultLayout>
    )
}
