import {
    Box,
    FormControl,
    FormControlLabel,
    InputLabel,
    MenuItem,
    Select,
    Switch,
    TextField,
    Typography,
} from '@mui/material'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import { useTheme } from '@mui/material/styles'
import dayjs, { Dayjs } from 'dayjs'
import utc from 'dayjs/plugin/utc'

dayjs.extend(utc)

interface EventDetailsProps {
    name: string
    status: 'scheduled' | 'completed' | 'canceled' | 'active'
    date: string
    isPublic: boolean
    isCommentsAllowed: boolean
    setFieldValue: (field: string, value: any) => void
    errors: { name?: string; status?: string; date?: string }
    touched: { name?: boolean; status?: boolean; date?: boolean }
}

export default function EventDetails({
    name,
    status,
    date,
    isPublic,
    isCommentsAllowed,
    setFieldValue,
    errors,
    touched,
}: EventDetailsProps) {
    const theme = useTheme()

    return (
        <Box
            sx={{
                display: 'flex',
                flexDirection: 'column',
                gap: 3,
                maxWidth: '400px',
                width: '100%',
            }}
        >
            <TextField
                fullWidth
                label="Event Name"
                name="name"
                value={name}
                onChange={(e) => setFieldValue('name', e.target.value)}
                error={touched.name && !!errors.name}
                helperText={touched.name && errors.name}
                sx={{
                    bgcolor: theme.palette.background.paper,
                }}
            />
            <FormControl
                fullWidth
                sx={{ bgcolor: theme.palette.background.paper }}
                error={touched.status && !!errors.status}
            >
                <InputLabel>Status</InputLabel>
                <Select
                    value={status}
                    onChange={(e) => setFieldValue('status', e.target.value)}
                    label="Status"
                >
                    <MenuItem value="active">Active</MenuItem>
                    <MenuItem value="scheduled">Scheduled</MenuItem>
                    <MenuItem value="completed">Completed</MenuItem>
                    <MenuItem value="canceled">Canceled</MenuItem>
                </Select>
                {touched.status && errors.status && (
                    <Typography
                        variant="caption"
                        sx={{ color: theme.palette.error.main, mt: 1 }}
                    >
                        {errors.status}
                    </Typography>
                )}
            </FormControl>
            <DatePicker
                label="Event Date"
                value={date ? dayjs(date) : null}
                onChange={(date: Dayjs | null) =>
                    setFieldValue(
                        'date',
                        date
                            ? date.utc().format('YYYY-MM-DD') + 'T00:00:00Z'
                            : '',
                    )
                }
                sx={{ width: '100%', bgcolor: theme.palette.background.paper }}
                slotProps={{
                    textField: {
                        error: touched.date && !!errors.date,
                        helperText: touched.date && errors.date,
                    },
                }}
            />
            <FormControlLabel
                control={
                    <Switch
                        checked={isPublic}
                        onChange={(e) =>
                            setFieldValue('is_public', e.target.checked)
                        }
                        color="primary"
                    />
                }
                label="Public Event"
                sx={{ color: theme.palette.text.primary }}
            />
            <FormControlLabel
                control={
                    <Switch
                        checked={isCommentsAllowed}
                        onChange={(e) =>
                            setFieldValue(
                                'is_comments_allowed',
                                e.target.checked,
                            )
                        }
                        color="primary"
                    />
                }
                label="Allow Comments"
                sx={{ color: theme.palette.text.primary }}
            />
        </Box>
    )
}
