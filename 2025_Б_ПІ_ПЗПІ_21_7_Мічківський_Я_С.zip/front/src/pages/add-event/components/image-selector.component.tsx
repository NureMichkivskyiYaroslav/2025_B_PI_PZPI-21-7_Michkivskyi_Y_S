import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Fab,
    IconButton,
    Typography,
    useTheme,
} from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import CloseIcon from '@mui/icons-material/Close'
import ZoomInIcon from '@mui/icons-material/ZoomIn'
import { useState } from 'react'
import { useImages } from '../../../shared/hooks/use-images.hook.ts'
import { Image } from '../../../shared/common/interfaces/image.interface.ts'
import ImageZoomDialog from '../../../shared/components/image-zoom-dialog.component.tsx'

interface ImageSelectorProps {
    value: string[]
    onChange: (ids: string[]) => void
    onOpenArchive: (event: React.MouseEvent) => void
    onOpenUpload: (event: React.MouseEvent) => void
}

export default function ImageSelector({
    value,
    onChange,
    onOpenArchive,
    onOpenUpload,
}: ImageSelectorProps) {
    const theme = useTheme()
    const { images } = useImages()
    const [zoomedImage, setZoomedImage] = useState<Image | null>(null)
    const [openConfirmModal, setOpenConfirmModal] = useState(false)
    const [imageToRemove, setImageToRemove] = useState<string | null>(null)

    const selectedImages = images.filter((img) => value.includes(img.id))

    const handleRequestRemove = (id: string) => {
        setImageToRemove(id)
        setOpenConfirmModal(true)
    }

    const handleConfirmRemove = () => {
        if (imageToRemove) {
            onChange(value.filter((imgId) => imgId !== imageToRemove))
        }
        setOpenConfirmModal(false)
        setImageToRemove(null)
    }

    const handleCancelRemove = () => {
        setOpenConfirmModal(false)
        setImageToRemove(null)
    }

    const handleZoom = (image: Image | null) => {
        setZoomedImage(image)
    }

    return (
        <Box sx={{ mt: 3 }}>
            <Typography
                variant="h6"
                sx={{
                    color: theme.palette.text.primary,
                    mb: 2,
                    fontWeight: 'bold',
                    fontSize: '1.25rem',
                }}
            >
                Images
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                <Box sx={{ maxWidth: '200px', flex: 'none' }}>
                    <Box
                        component="button"
                        onClick={(event) => onOpenArchive(event)}
                        sx={{
                            width: '100%',
                            padding: '8px 16px',
                            borderRadius: '4px',
                            border: `1px solid ${theme.palette.divider}`,
                            backgroundColor: theme.palette.background.paper,
                            color: theme.palette.text.primary,
                            textAlign: 'center',
                            fontSize: '0.875rem',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: theme.palette.action.hover,
                            },
                        }}
                    >
                        Select from Archive
                    </Box>
                </Box>
                <Fab
                    size="medium"
                    color="primary"
                    onClick={(event) => onOpenUpload(event)}
                    sx={{ bgcolor: theme.palette.primary.main }}
                >
                    <AddIcon />
                </Fab>
            </Box>
            {selectedImages.length === 0 ? (
                <Typography
                    variant="body2"
                    color={theme.palette.text.secondary}
                    sx={{ mt: 2, p: 1 }}
                >
                    No images selected
                </Typography>
            ) : (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {selectedImages.map((image) => (
                        <Box
                            key={image.id}
                            sx={{
                                position: 'relative',
                                width: 100,
                                height: 100,
                                borderRadius: 1,
                                overflow: 'hidden',
                                '&:hover .actions': { opacity: 1 },
                            }}
                        >
                            <img
                                src={image.link}
                                alt={image.id}
                                style={{
                                    width: '100%',
                                    height: '100%',
                                    objectFit: 'cover',
                                }}
                            />
                            <Box
                                className="actions"
                                sx={{
                                    position: 'absolute',
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    bgcolor: 'rgba(0,0,0,0.5)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: 1,
                                    opacity: 0,
                                    transition: 'opacity 0.2s',
                                }}
                            >
                                <IconButton
                                    size="small"
                                    sx={{ color: theme.palette.common.white }}
                                    onClick={() => handleZoom(image)}
                                >
                                    <ZoomInIcon fontSize="small" />
                                </IconButton>
                                <IconButton
                                    size="small"
                                    sx={{ color: theme.palette.common.white }}
                                    onClick={() =>
                                        handleRequestRemove(image.id)
                                    }
                                >
                                    <CloseIcon fontSize="small" />
                                </IconButton>
                            </Box>
                        </Box>
                    ))}
                </Box>
            )}
            <ImageZoomDialog
                image={zoomedImage}
                onClose={() => handleZoom(null)}
                onNavigate={() => {}}
            />
            <Dialog open={openConfirmModal} onClose={handleCancelRemove}>
                <DialogTitle>Confirm Removal</DialogTitle>
                <DialogContent>
                    <Typography>
                        Are you sure you want to remove this image?
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCancelRemove}>Cancel</Button>
                    <Button
                        onClick={handleConfirmRemove}
                        variant="contained"
                        sx={{ bgcolor: theme.palette.primary.main }}
                    >
                        Confirm
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    )
}
