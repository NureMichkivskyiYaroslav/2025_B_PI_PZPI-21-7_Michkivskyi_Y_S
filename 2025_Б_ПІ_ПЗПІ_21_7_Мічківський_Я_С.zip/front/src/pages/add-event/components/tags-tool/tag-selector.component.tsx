import { useMemo, useState } from 'react'
import {
    Box,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Fab,
    TextField,
    Typography,
    useTheme,
} from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import TagItem from './tag-item.component'
import { useTags } from '../../../../shared/hooks/use-tags.hook.ts'

interface TagSelectorProps {
    value: string[]
    onChange: (value: string[]) => void
}

export default function TagSelector({ value, onChange }: TagSelectorProps) {
    const theme = useTheme()
    const { tags, isLoadingTags, createTag, isCreatingTag } = useTags()
    const [searchQuery, setSearchQuery] = useState('')
    const [openModal, setOpenModal] = useState(false)
    const [newTagName, setNewTagName] = useState('')

    const filteredTags = useMemo(() => {
        if (!searchQuery) return tags
        const lowerQuery = searchQuery.toLowerCase()
        return tags.filter((tag) => tag.name.toLowerCase().includes(lowerQuery))
    }, [tags, searchQuery])

    const handleOpenModal = () => setOpenModal(true)
    const handleCloseModal = () => {
        setOpenModal(false)
        setNewTagName('')
    }

    const handleAddTag = () => {
        if (!newTagName) return
        createTag(
            { name: newTagName },
            {
                onSuccess: (newTag) => {
                    onChange([...value, newTag.id])
                    handleCloseModal()
                },
            },
        )
    }

    const handleSelectTag = (tagId: string) => {
        if (!value.includes(tagId)) {
            onChange([...value, tagId])
        }
    }

    const handleDeleteTag = (tagId: string) => {
        onChange(value.filter((id) => id !== tagId))
    }

    return (
        <Box sx={{ mb: 2, width: '100%' }}>
            <Typography
                variant="h6"
                sx={{
                    color: theme.palette.text.primary,
                    mb: 2,
                    fontWeight: 'bold',
                    fontSize: '1.25rem',
                }}
            >
                Tags
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <TextField
                    label="Search Tags"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    size="small"
                    sx={{
                        maxWidth: '200px',
                        bgcolor: theme.palette.background.paper,
                        borderRadius: '4px',
                        '& .MuiOutlinedInput-root': {
                            borderRadius: '4px',
                            bgcolor: theme.palette.background.paper,
                        },
                        '& .MuiOutlinedInput-notchedOutline': {
                            borderColor: theme.palette.divider,
                        },
                    }}
                />
                <Fab
                    size="medium"
                    color="primary"
                    onClick={handleOpenModal}
                    sx={{ bgcolor: theme.palette.primary.main }}
                >
                    <AddIcon />
                </Fab>
            </Box>
            <Box
                sx={{
                    maxHeight: '100px',
                    overflowY: 'auto',
                    border: `1px solid ${theme.palette.divider}`,
                    borderRadius: '4px',
                    bgcolor: theme.palette.background.paper,
                    p: 0.5,
                }}
            >
                {isLoadingTags ? (
                    <Box
                        sx={{ display: 'flex', justifyContent: 'center', p: 1 }}
                    >
                        <CircularProgress size={24} />
                    </Box>
                ) : filteredTags.length === 0 ? (
                    <Typography
                        color={theme.palette.text.secondary}
                        sx={{ p: 1 }}
                    >
                        No tags found
                    </Typography>
                ) : (
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {filteredTags.map((tag) => (
                            <TagItem
                                key={tag.id}
                                tag={tag}
                                isSelected={value.includes(tag.id)}
                                onSelect={handleSelectTag}
                                onRemove={handleDeleteTag}
                            />
                        ))}
                    </Box>
                )}
            </Box>
            {value.length === 0 ? (
                <Typography
                    variant="body2"
                    color={theme.palette.text.secondary}
                    sx={{ mt: 2, p: 1 }}
                >
                    No tags selected
                </Typography>
            ) : (
                <Box sx={{ mt: 2 }}>
                    <Typography
                        variant="body2"
                        sx={{ color: theme.palette.text.primary, mb: 1 }}
                    >
                        Selected Tags
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {value.map((tagId) => {
                            const tag = tags.find((t) => t.id === tagId)
                            return tag ? (
                                <TagItem
                                    key={tag.id}
                                    tag={tag}
                                    isSelected={true}
                                    onSelect={handleSelectTag}
                                    onRemove={handleDeleteTag}
                                />
                            ) : null
                        })}
                    </Box>
                </Box>
            )}
            <Dialog open={openModal} onClose={handleCloseModal}>
                <DialogTitle>Create New Tag</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Tag Name"
                        fullWidth
                        value={newTagName}
                        onChange={(e) => setNewTagName(e.target.value)}
                        sx={{ bgcolor: theme.palette.background.paper }}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal}>Cancel</Button>
                    <Button
                        onClick={handleAddTag}
                        disabled={!newTagName || isCreatingTag}
                        variant="contained"
                        sx={{ bgcolor: theme.palette.primary.main }}
                    >
                        {isCreatingTag ? (
                            <CircularProgress size={24} color="inherit" />
                        ) : (
                            'Create'
                        )}
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    )
}
