import { Chip, useTheme } from '@mui/material'
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline'
import CloseIcon from '@mui/icons-material/Close'
import { Tag } from '../../../../shared/common/interfaces/tag.interface.ts'

interface TagItemProps {
    tag: Tag
    isSelected: boolean
    onSelect: (tagId: string) => void
    onRemove: (tagId: string) => void
}

export default function TagItem({
    tag,
    isSelected,
    onSelect,
    onRemove,
}: TagItemProps) {
    const theme = useTheme()

    return (
        <Chip
            label={tag.name}
            size="small"
            sx={{
                borderRadius: '16px',
                bgcolor: isSelected
                    ? theme.palette.primary.light
                    : theme.palette.grey[200],
                color: theme.palette.text.primary,
                height: '24px',
                m: 0.5,
                '& .MuiChip-label': {
                    pr: isSelected ? 0.5 : 2,
                },
            }}
            deleteIcon={
                isSelected ? (
                    <CloseIcon
                        sx={{
                            color: theme.palette.primary.main,
                            fontSize: '16px',
                        }}
                    />
                ) : (
                    <AddCircleOutlineIcon
                        sx={{
                            color: theme.palette.primary.main,
                            fontSize: '16px',
                        }}
                    />
                )
            }
            onDelete={() => (isSelected ? onRemove(tag.id) : onSelect(tag.id))}
        />
    )
}
