import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogTitle,
    Typography,
    useTheme,
} from '@mui/material'
import { useImages } from '../../../shared/hooks/use-images.hook.ts'
import { getDate } from '../../../shared/helpers/cloudinary.helper.ts'
import { useState } from 'react'

interface ArchiveSelectModalProps {
    open: boolean
    onClose: () => void
    selectedIds: string[]
    onSelect: (ids: string[]) => void
}

export default function ArchiveSelectModal({
    open,
    onClose,
    selectedIds,
    onSelect,
}: ArchiveSelectModalProps) {
    const theme = useTheme()
    const { images } = useImages()
    const [selectedInModal, setSelectedInModal] = useState<string[]>([])

    const groupedImages = images.reduce(
        (groups, image) => {
            const timestamp = image.link.match(/v(\d+)/)?.[1]
            const date = timestamp
                ? new Date(Number(timestamp) * 1000).toLocaleDateString(
                      'en-US',
                      {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                      },
                  )
                : 'Unknown Date'
            groups[date] = groups[date] || []
            groups[date].push(image)
            return groups
        },
        {} as { [date: string]: typeof images },
    )

    const sortedDates = Object.keys(groupedImages).sort((a, b) => {
        const dateA = new Date(a).getTime()
        const dateB = new Date(b).getTime()
        return dateB - dateA
    })

    const handleToggleSelect = (id: string) => {
        if (selectedIds.includes(id)) return
        setSelectedInModal((prev) =>
            prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
        )
    }

    const handleConfirm = () => {
        onSelect(selectedInModal)
        setSelectedInModal([]) // Reset modal selection
        onClose()
    }

    return (
        <Dialog
            open={open}
            onClose={onClose}
            maxWidth="lg"
            sx={{
                '& .MuiDialog-paper': {
                    width: '100%',
                    maxWidth: '1200px',
                    margin: '0 auto',
                    borderRadius: '8px',
                    p: { xs: 2, sm: 4 },
                },
                '@media (max-width: 960px)': {
                    '& .MuiDialog-paper': {
                        maxWidth: '90vw',
                        margin: '16px',
                    },
                },
            }}
        >
            <DialogTitle sx={{ textAlign: 'center', fontWeight: 'bold' }}>
                Select Images from Archive
            </DialogTitle>
            <Box sx={{ p: { xs: 2, sm: 4 } }}>
                {sortedDates.length === 0 ? (
                    <Typography
                        sx={{
                            textAlign: 'center',
                            color: theme.palette.text.secondary,
                        }}
                    >
                        No images in archive
                    </Typography>
                ) : (
                    sortedDates.map((date) => (
                        <Box key={date} sx={{ mb: 4 }}>
                            <Typography
                                variant="h6"
                                sx={{
                                    color: theme.palette.text.primary,
                                    mb: 2,
                                }}
                            >
                                {date}
                            </Typography>
                            <Box
                                sx={{
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                    gap: '8px',
                                }}
                            >
                                {groupedImages[date]
                                    .sort((a, b) => {
                                        const timestampA = new Date(
                                            getDate(a.link),
                                        ).getTime()
                                        const timestampB = new Date(
                                            getDate(b.link),
                                        ).getTime()
                                        return timestampB - timestampA
                                    })
                                    .map((image) => (
                                        <Box
                                            key={image.id}
                                            sx={{
                                                width: 100,
                                                height: 100,
                                                borderRadius: 1,
                                                overflow: 'hidden',
                                                opacity: selectedIds.includes(
                                                    image.id,
                                                )
                                                    ? 0.5
                                                    : 1,
                                                cursor: selectedIds.includes(
                                                    image.id,
                                                )
                                                    ? 'not-allowed'
                                                    : 'pointer',
                                                outline:
                                                    selectedInModal.includes(
                                                        image.id,
                                                    )
                                                        ? `2px solid ${theme.palette.primary.main}`
                                                        : 'none',
                                                '&:hover': {
                                                    outline:
                                                        selectedIds.includes(
                                                            image.id,
                                                        )
                                                            ? 'none'
                                                            : `2px solid ${theme.palette.primary.main}`,
                                                },
                                            }}
                                            onClick={() =>
                                                handleToggleSelect(image.id)
                                            }
                                        >
                                            <img
                                                src={image.link}
                                                alt={image.id}
                                                style={{
                                                    width: '100%',
                                                    height: '100%',
                                                    objectFit: 'cover',
                                                }}
                                            />
                                        </Box>
                                    ))}
                            </Box>
                        </Box>
                    ))
                )}
            </Box>
            <DialogActions sx={{ justifyContent: 'center', pb: 2 }}>
                <Button
                    type="button"
                    onClick={onClose}
                    sx={{ minWidth: '120px' }}
                >
                    Cancel
                </Button>
                <Button
                    type="button"
                    variant="contained"
                    onClick={handleConfirm}
                    disabled={selectedInModal.length === 0}
                    sx={{
                        minWidth: '120px',
                        bgcolor: theme.palette.primary.main,
                    }}
                >
                    Confirm
                </Button>
            </DialogActions>
        </Dialog>
    )
}
