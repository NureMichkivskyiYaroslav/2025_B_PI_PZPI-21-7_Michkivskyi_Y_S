import { BubbleMenu, EditorContent, useEditor } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import TextStyle from '@tiptap/extension-text-style'
import Color from '@tiptap/extension-color'
import { useCallback, useEffect, useState } from 'react'
import { Button, Menu, MenuItem } from '@mui/material'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'
import MoreHorizIcon from '@mui/icons-material/MoreHoriz'
import { useTheme } from '@mui/material/styles'

interface EventDescriptionEditorProps {
    value: string
    onChange: (value: string) => void
}

const extensions = [StarterKit, TextStyle, Color]

export default function EventDescriptionEditor({
    value,
    onChange,
}: EventDescriptionEditorProps) {
    const theme = useTheme()
    const isDarkMode = theme.palette.mode === 'dark'

    const editor = useEditor({
        extensions,
        content: value || '<p></p>',
        editorProps: {
            attributes: {
                class: 'prose max-w-none focus:outline-none p-4 min-h-[200px] [&_ul]:list-disc [&_ol]:list-decimal [&_ul]:pl-6 [&_ol]:pl-6',
            },
        },
        onUpdate: ({ editor }) => {
            onChange(editor.getHTML())
        },
    })

    const [moreAnchorEl, setMoreAnchorEl] = useState<null | HTMLElement>(null)
    const moreOpen = Boolean(moreAnchorEl)
    const [colorAnchorEl, setColorAnchorEl] = useState<null | HTMLElement>(null)
    const colorOpen = Boolean(colorAnchorEl)

    const toggleBold = useCallback(
        (e: React.MouseEvent<HTMLButtonElement>) => {
            e.preventDefault()
            editor?.chain().focus().toggleBold().run()
        },
        [editor],
    )

    const toggleItalic = useCallback(
        (e: React.MouseEvent<HTMLButtonElement>) => {
            e.preventDefault()
            editor?.chain().focus().toggleItalic().run()
        },
        [editor],
    )

    const toggleStrike = useCallback(
        (e: React.MouseEvent<HTMLButtonElement>) => {
            e.preventDefault()
            editor?.chain().focus().toggleStrike().run()
        },
        [editor],
    )

    const setParagraph = useCallback(
        (e: React.MouseEvent<HTMLElement>) => {
            e.preventDefault()
            editor?.chain().focus().setParagraph().run()
        },
        [editor],
    )

    const toggleBulletList = useCallback(
        (e: React.MouseEvent<HTMLElement>) => {
            e.preventDefault()
            editor?.chain().focus().toggleBulletList().run()
            setMoreAnchorEl(null)
        },
        [editor],
    )

    const toggleOrderedList = useCallback(
        (e: React.MouseEvent<HTMLElement>) => {
            e.preventDefault()
            editor?.chain().focus().toggleOrderedList().run()
            setMoreAnchorEl(null)
        },
        [editor],
    )

    const setHorizontalRule = useCallback(
        (e: React.MouseEvent<HTMLElement>) => {
            e.preventDefault()
            editor?.chain().focus().setHorizontalRule().run()
            setMoreAnchorEl(null)
        },
        [editor],
    )

    const setColor = useCallback(
        (color: string) => (e: React.MouseEvent<HTMLElement>) => {
            e.preventDefault()
            if (color === 'default') {
                editor?.chain().focus().unsetColor().run()
            } else {
                editor?.chain().focus().setColor(color).run()
            }
            setColorAnchorEl(null)
        },
        [editor],
    )

    const undo = useCallback(
        (e: React.MouseEvent<HTMLButtonElement>) => {
            e.preventDefault()
            editor?.chain().focus().undo().run()
        },
        [editor],
    )

    const redo = useCallback(
        (e: React.MouseEvent<HTMLButtonElement>) => {
            e.preventDefault()
            editor?.chain().focus().redo().run()
        },
        [editor],
    )

    const handleMoreClick = (event: React.MouseEvent<HTMLElement>) => {
        event.preventDefault()
        setMoreAnchorEl(event.currentTarget)
    }

    const handleMoreClose = (event: React.MouseEvent<HTMLElement>) => {
        event.preventDefault()
        setMoreAnchorEl(null)
    }

    const handleColorClick = (event: React.MouseEvent<HTMLElement>) => {
        event.preventDefault()
        setColorAnchorEl(event.currentTarget)
    }

    const handleColorClose = (event: React.MouseEvent<HTMLElement>) => {
        event.preventDefault()
        setColorAnchorEl(null)
    }

    useEffect(() => {
        if (editor && value !== editor.getHTML()) {
            editor.commands.setContent(value || '<p></p>')
        }
    }, [editor, value])

    if (!editor) {
        return null
    }

    return (
        <div
            className={`w-full max-w-3xl mx-auto ${
                isDarkMode ? 'bg-dark-default' : 'bg-light-default'
            }`}
        >
            <div
                className={`p-2 rounded-t-lg border ${
                    isDarkMode
                        ? 'bg-dark-paper border-dark-divider'
                        : 'bg-light-paper border-light-divider'
                } flex flex-wrap gap-2`}
            >
                <button
                    onClick={toggleBold}
                    className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? `text-dark-primary ${
                                  editor.isActive('bold')
                                      ? 'bg-gray-700'
                                      : 'hover:bg-gray-700'
                              }`
                            : `text-light-primary ${
                                  editor.isActive('bold')
                                      ? 'bg-gray-200'
                                      : 'hover:bg-gray-200'
                              }`
                    }`}
                    title="Bold"
                >
                    <strong>B</strong>
                </button>
                <button
                    onClick={toggleItalic}
                    className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? `text-dark-primary ${
                                  editor.isActive('italic')
                                      ? 'bg-gray-700'
                                      : 'hover:bg-gray-700'
                              }`
                            : `text-light-primary ${
                                  editor.isActive('italic')
                                      ? 'bg-gray-200'
                                      : 'hover:bg-gray-200'
                              }`
                    }`}
                    title="Italic"
                >
                    <i>I</i>
                </button>
                <button
                    onClick={toggleStrike}
                    className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? `text-dark-primary ${
                                  editor.isActive('strike')
                                      ? 'bg-gray-700'
                                      : 'hover:bg-gray-700'
                              }`
                            : `text-light-primary ${
                                  editor.isActive('strike')
                                      ? 'bg-gray-200'
                                      : 'hover:bg-gray-200'
                              }`
                    }`}
                    title="Strike"
                >
                    <s>S</s>
                </button>
                <Button
                    onClick={handleColorClick}
                    endIcon={<KeyboardArrowDownIcon />}
                    sx={{
                        padding: '4px 12px',
                        borderRadius: '4px',
                        minWidth: 'auto',
                        textTransform: 'none',
                        color: theme.palette.text.primary,
                        backgroundColor: 'transparent',
                        '&:hover': {
                            backgroundColor: theme.palette.action.hover,
                        },
                    }}
                    title="Text Color"
                >
                    Color
                </Button>
                <Menu
                    anchorEl={colorAnchorEl}
                    open={colorOpen}
                    onClose={handleColorClose}
                    slotProps={{
                        paper: {
                            'aria-labelledby': 'color-button',
                        },
                    }}
                >
                    <MenuItem
                        onClick={setColor('#ff0000')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        <span style={{ color: '#ff0000' }}>Red</span>
                    </MenuItem>
                    <MenuItem
                        onClick={setColor('#ffaa00')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        <span style={{ color: '#ffaa00' }}>Yellow</span>
                    </MenuItem>
                    <MenuItem
                        onClick={setColor('#00ff00')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        <span style={{ color: '#00ff00' }}>Green</span>
                    </MenuItem>
                    <MenuItem
                        onClick={setColor('#0000ff')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        <span style={{ color: '#0000ff' }}>Blue</span>
                    </MenuItem>
                    <MenuItem
                        onClick={setColor('#800080')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        <span style={{ color: '#800080' }}>Purple</span>
                    </MenuItem>
                    <MenuItem
                        onClick={setColor('default')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        Remove Color
                    </MenuItem>
                </Menu>
                <Button
                    onClick={handleMoreClick}
                    sx={{
                        padding: '4px 12px',
                        borderRadius: '4px',
                        minWidth: 'auto',
                        textTransform: 'none',
                        color: theme.palette.text.primary,
                        backgroundColor: 'transparent',
                        '&:hover': {
                            backgroundColor: theme.palette.action.hover,
                        },
                    }}
                    title="More Options"
                >
                    <MoreHorizIcon />
                </Button>
                <Menu
                    anchorEl={moreAnchorEl}
                    open={moreOpen}
                    onClose={handleMoreClose}
                    slotProps={{
                        paper: {
                            'aria-labelledby': 'more-button',
                        },
                    }}
                >
                    <MenuItem
                        onClick={setParagraph}
                        selected={editor.isActive('paragraph')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        Paragraph
                    </MenuItem>
                    <MenuItem
                        onClick={toggleBulletList}
                        selected={editor.isActive('bulletList')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        Bullet List
                    </MenuItem>
                    <MenuItem
                        onClick={toggleOrderedList}
                        selected={editor.isActive('orderedList')}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        Ordered List
                    </MenuItem>
                    <MenuItem
                        onClick={setHorizontalRule}
                        sx={{ color: theme.palette.text.primary }}
                    >
                        Horizontal Rule
                    </MenuItem>
                </Menu>
                <button
                    onClick={undo}
                    className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? editor.can().undo()
                                ? 'text-dark-primary hover:bg-gray-700'
                                : 'text-dark-disabled'
                            : editor.can().undo()
                              ? 'text-light-primary hover:bg-gray-200'
                              : 'text-light-disabled'
                    }`}
                    title="Undo"
                    disabled={!editor.can().undo()}
                >
                    ↺
                </button>
                <button
                    onClick={redo}
                    className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? editor.can().redo()
                                ? 'text-dark-primary hover:bg-gray-700'
                                : 'text-dark-disabled'
                            : editor.can().redo()
                              ? 'text-light-primary hover:bg-gray-200'
                              : 'text-light-disabled'
                    }`}
                    title="Redo"
                    disabled={!editor.can().redo()}
                >
                    ↻
                </button>
            </div>
            <div
                className={`border border-t-0 rounded-b-lg shadow-sm ${
                    isDarkMode
                        ? 'bg-dark-paper border-dark-divider'
                        : 'bg-light-paper border-light-divider'
                }`}
            >
                <EditorContent editor={editor} />
            </div>
            <BubbleMenu
                editor={editor}
                tippyOptions={{ duration: 100 }}
                className={`flex gap-1 p-1 rounded border shadow-lg ${
                    isDarkMode
                        ? 'bg-dark-paper border-dark-divider'
                        : 'bg-light-paper border-light-divider'
                }`}
            >
                <button
                    onClick={toggleBold}
                    className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? `text-dark-primary ${
                                  editor.isActive('bold')
                                      ? 'bg-gray-700'
                                      : 'hover:bg-gray-700'
                              }`
                            : `text-light-primary ${
                                  editor.isActive('bold')
                                      ? 'bg-gray-200'
                                      : 'hover:bg-gray-200'
                              }`
                    }`}
                >
                    <strong>B</strong>
                </button>
                <button
                    onClick={toggleItalic}
                    className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? `text-dark-primary ${
                                  editor.isActive('italic')
                                      ? 'bg-gray-700'
                                      : 'hover:bg-gray-700'
                              }`
                            : `text-light-primary ${
                                  editor.isActive('italic')
                                      ? 'bg-gray-200'
                                      : 'hover:bg-gray-200'
                              }`
                    }`}
                >
                    <i>I</i>
                </button>
                <button
                    onClick={toggleStrike}
                    className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                        isDarkMode
                            ? `text-dark-primary ${
                                  editor.isActive('strike')
                                      ? 'bg-gray-700'
                                      : 'hover:bg-gray-700'
                              }`
                            : `text-light-primary ${
                                  editor.isActive('strike')
                                      ? 'bg-gray-200'
                                      : 'hover:bg-gray-200'
                              }`
                    }`}
                >
                    <s>S</s>
                </button>
            </BubbleMenu>
        </div>
    )
}
