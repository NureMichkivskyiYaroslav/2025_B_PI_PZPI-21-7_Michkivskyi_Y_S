import * as Yup from 'yup'

export const eventValidationSchema = Yup.object({
    name: Yup.string()
        .min(3, 'Event name must be at least 3 characters')
        .required('Event name is required'),
    description: Yup.string()
        .min(10, 'Description must be at least 10 characters')
        .required('Description is required'),
    date: Yup.string()
        .matches(
            /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/,
            'Date must be in YYYY-MM-DDTHH:mm:ssZ format (e.g., 2025-06-09T12:00:00Z)',
        )
        .required('Event date is required'),
    status: Yup.string()
        .oneOf(
            ['scheduled', 'completed', 'canceled', 'active'],
            'Invalid status',
        )
        .required('Status is required'),
    tags: Yup.array().of(Yup.string().defined()),
    is_comments_allowed: Yup.boolean().required('Comments allowed is required'),
    image_ids: Yup.array().of(Yup.string().defined()),
    is_public: Yup.boolean().required('Public setting is required'),
})
