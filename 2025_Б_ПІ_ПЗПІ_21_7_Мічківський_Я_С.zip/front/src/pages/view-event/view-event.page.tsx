import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
    Container,
    Box,
    CircularProgress,
    Typography,
    Button,
} from '@mui/material'
import DefaultLayout from '../../shared/components/default-layout.component'
import { useEvent } from '../../shared/hooks/use-events.hook.ts'
import { useComments } from '../../shared/hooks/use-comments.hook.ts'
import TagsSection from './components/tag-section.component.tsx'
import ChatSection from './components/chat-section.component.tsx'
import ViewEventDetails from './components/event-details.component.tsx'
import ManageEditorsModal from './components/manage-editors-modal.component'

export default function ViewEvent() {
    const { id: eventId } = useParams<{ id: string }>()
    const { data: event, isLoading, error } = useEvent(eventId!)
    const { postComment } = useComments(eventId!)
    const [openManageEditors, setOpenManageEditors] = useState(false)
    const navigate = useNavigate()

    if (!eventId)
        return <Typography color="error">Event ID is missing</Typography>
    if (isLoading) return <CircularProgress />
    if (error) return <Typography color="error">{error.message}</Typography>
    if (!event) return <Typography>Event not found</Typography>

    const isEditor = event.access_type === 'editor'
    const isOwner = event.access_type === 'owner'

    return (
        <DefaultLayout>
            <Container maxWidth="lg" sx={{ py: 4 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                    <ViewEventDetails event={event} />
                    {(isEditor || isOwner) && (
                        <TagsSection tags={event.tag_objects} />
                    )}
                    {(isEditor || isOwner) && (
                        <Button
                            variant="contained"
                            onClick={() => navigate(`/events/${eventId}/edit`)}
                            className="w-[200px]"
                        >
                            Edit Event
                        </Button>
                    )}
                    {isOwner && (
                        <Button
                            variant="outlined"
                            onClick={() => setOpenManageEditors(true)}
                            className="w-[200px]"
                        >
                            Manage Editors
                        </Button>
                    )}
                    {event.is_comments_allowed && (
                        <ChatSection
                            comments={event.comments}
                            isCommentsAllowed={event.is_comments_allowed}
                            postComment={postComment}
                        />
                    )}
                </Box>
                <ManageEditorsModal
                    eventId={eventId}
                    editors={event.can_edit_users || []}
                    open={openManageEditors}
                    onClose={() => setOpenManageEditors(false)}
                />
            </Container>
        </DefaultLayout>
    )
}
