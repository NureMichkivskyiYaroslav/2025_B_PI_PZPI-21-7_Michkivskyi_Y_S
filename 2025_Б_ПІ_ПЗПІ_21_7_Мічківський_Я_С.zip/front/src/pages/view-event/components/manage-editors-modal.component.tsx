import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    List,
    ListItem,
    ListItemSecondaryAction,
    ListItemText,
    Typography,
    Button,
    Divider,
} from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import CloseIcon from '@mui/icons-material/Close'
import { useFriends } from '../../../shared/hooks/use-friends.hook.ts'
import { useEditorPermissions } from '../../../shared/hooks/use-permissions.hook.ts'
import { Editor } from '../../../shared/common/interfaces/event.interface.ts'

interface ManageEditorsModalProps {
    eventId: string
    editors: Editor[]
    open: boolean
    onClose: () => void
}

export default function ManageEditorsModal({
    eventId,
    editors,
    open,
    onClose,
}: ManageEditorsModalProps) {
    const { friends } = useFriends()
    const { addEditorPermission, removeEditorPermission } =
        useEditorPermissions(eventId)

    const handleAddEditor = (userId: string) => {
        addEditorPermission(userId)
    }

    const handleRemoveEditor = (userId: string) => {
        removeEditorPermission(userId)
    }

    const nonEditorFriends = friends.filter(
        (friend) =>
            !editors.map((editor) => editor.id).includes(friend.user_id),
    )

    return (
        <Dialog
            open={open}
            onClose={onClose}
            maxWidth="sm"
            fullWidth
            sx={{
                '& .MuiDialog-paper': {
                    borderRadius: 2,
                    boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
                },
            }}
        >
            <DialogTitle
                sx={{ bgcolor: 'primary.main', color: 'white', mb: 2 }}
            >
                Manage Editors
            </DialogTitle>
            <DialogContent
                sx={{ px: 3, py: 2, maxHeight: '60vh', overflowY: 'auto' }}
            >
                <Typography variant="h6" sx={{ mb: 1, fontWeight: 'bold' }}>
                    Current Editors
                </Typography>
                {editors.length === 0 ? (
                    <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ mb: 2 }}
                    >
                        No editors assigned
                    </Typography>
                ) : (
                    <List sx={{ mb: 2 }}>
                        {editors.map((editor) => (
                            <ListItem
                                key={editor.id}
                                sx={{
                                    borderRadius: 1,
                                    '&:hover': {
                                        bgcolor: 'action.hover',
                                    },
                                    py: 1,
                                }}
                            >
                                <ListItemText primary={editor.name} />
                                <ListItemSecondaryAction>
                                    <IconButton
                                        edge="end"
                                        onClick={() =>
                                            handleRemoveEditor(editor.id)
                                        }
                                        sx={{ color: 'error.main' }}
                                        aria-label={`Remove editor ${editor.name}`}
                                    >
                                        <CloseIcon />
                                    </IconButton>
                                </ListItemSecondaryAction>
                            </ListItem>
                        ))}
                    </List>
                )}
                <Divider sx={{ my: 2 }} />
                <Typography variant="h6" sx={{ mb: 1, fontWeight: 'bold' }}>
                    Add Editors
                </Typography>
                {friends.length === 0 ? (
                    <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ mb: 2 }}
                    >
                        You have no friends to add as editors
                    </Typography>
                ) : nonEditorFriends.length === 0 ? (
                    <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ mb: 2 }}
                    >
                        All your friends are already editors
                    </Typography>
                ) : (
                    <List>
                        {nonEditorFriends.map((friend) => (
                            <ListItem
                                key={friend.user_id}
                                sx={{
                                    borderRadius: 1,
                                    '&:hover': {
                                        bgcolor: 'action.hover',
                                    },
                                    py: 1,
                                }}
                            >
                                <ListItemText primary={friend.user_name} />
                                <ListItemSecondaryAction>
                                    <IconButton
                                        edge="end"
                                        onClick={() =>
                                            handleAddEditor(friend.user_id)
                                        }
                                        sx={{ color: 'primary.main' }}
                                        aria-label={`Add editor ${friend.user_name}`}
                                    >
                                        <AddIcon />
                                    </IconButton>
                                </ListItemSecondaryAction>
                            </ListItem>
                        ))}
                    </List>
                )}
            </DialogContent>
            <DialogActions sx={{ px: 3, py: 2, bgcolor: 'background.paper' }}>
                <Button
                    variant="contained"
                    onClick={onClose}
                    sx={{
                        bgcolor: 'primary.main',
                        '&:hover': { bgcolor: 'primary.dark' },
                    }}
                >
                    Close
                </Button>
            </DialogActions>
        </Dialog>
    )
}
