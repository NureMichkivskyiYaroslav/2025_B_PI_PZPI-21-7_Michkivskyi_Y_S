import { Box, Chip, Typography } from '@mui/material'
import { Tag } from '../../../shared/common/interfaces/tag.interface.ts'

interface TagsSectionProps {
    tags: Tag[]
}

export default function TagsSection({ tags }: TagsSectionProps) {
    return (
        <Box>
            <Typography variant="h6">Your Tags</Typography>
            {tags.map((tag) => (
                <Chip key={tag.id} label={tag.name} />
            ))}
        </Box>
    )
}
