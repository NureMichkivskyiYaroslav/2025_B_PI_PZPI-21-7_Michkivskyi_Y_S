import { useState } from 'react'
import { Box, IconButton, Typography } from '@mui/material'
import ZoomInIcon from '@mui/icons-material/ZoomIn'
import { useImages } from '../../../shared/hooks/use-images.hook.ts'
import { Image } from '../../../shared/common/interfaces/image.interface.ts'
import ImageZoomDialog from '../../../shared/components/image-zoom-dialog.component.tsx'
import { generateImageUrl } from '../../../shared/helpers/cloudinary.helper.ts'

interface ImageGalleryProps {
    imageIds: string[]
}

export default function ImageGallery({ imageIds }: ImageGalleryProps) {
    const { images } = useImages()
    const [zoomedImage, setZoomedImage] = useState<Image | null>(null)
    const [currentIndex, setCurrentIndex] = useState(0)

    const uniqueImageIds = [...new Set(imageIds)]
    const selectedImages = uniqueImageIds
        .map((id) => images.find((img) => img.id === id))
        .filter((img): img is Image => !!img)

    const handleZoom = (image: Image, index: number) => {
        setZoomedImage(image)
        setCurrentIndex(index)
    }

    const handleNavigate = (direction: 'prev' | 'next') => {
        const newIndex =
            direction === 'prev'
                ? (currentIndex - 1 + selectedImages.length) %
                  selectedImages.length
                : (currentIndex + 1) % selectedImages.length
        setZoomedImage(selectedImages[newIndex])
        setCurrentIndex(newIndex)
    }

    if (selectedImages.length === 0) {
        return (
            <Typography variant="body2" color="text.secondary">
                No images available
            </Typography>
        )
    }

    return (
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 2 }}>
            {selectedImages.map((image, index) => (
                <Box
                    key={image.id}
                    sx={{
                        position: 'relative',
                        width: 100,
                        height: 100,
                        borderRadius: 1,
                        overflow: 'hidden',
                        '&:hover .actions': { opacity: 1 },
                    }}
                >
                    <img
                        src={generateImageUrl(image.id)}
                        alt={image.id}
                        style={{
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover',
                        }}
                    />
                    <Box
                        className="actions"
                        sx={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            bgcolor: 'rgba(0,0,0,0.5)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            opacity: 0,
                            transition: 'opacity 0.2s',
                        }}
                    >
                        <IconButton
                            size="small"
                            sx={{ color: 'white' }}
                            onClick={() => handleZoom(image, index)}
                        >
                            <ZoomInIcon fontSize="small" />
                        </IconButton>
                    </Box>
                </Box>
            ))}
            <ImageZoomDialog
                image={zoomedImage}
                onClose={() => setZoomedImage(null)}
                onNavigate={handleNavigate}
            />
        </Box>
    )
}
