import { Box, Typography } from '@mui/material'
import { EditorContent, useEditor } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import TextStyle from '@tiptap/extension-text-style'
import Color from '@tiptap/extension-color'
import { Event } from '../../../shared/common/interfaces/event.interface.ts'
import ImageGallery from './image-gallery.component.tsx'

interface EventDetailsProps {
    event: Event
}

export default function EventDetails({ event }: EventDetailsProps) {
    const editor = useEditor({
        extensions: [StarterKit, TextStyle, Color],
        content: event.description,
        editable: false,
        editorProps: {
            attributes: {
                class: 'prose max-w-none p-4 [&_ul]:list-disc [&_ol]:list-decimal [&_ul]:pl-6 [&_ol]:pl-6',
            },
        },
    })

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Typography variant="h4">Event: {event.name}</Typography>
            <Typography variant="body1">
                Owner: {event.owner.user_name}
            </Typography>
            <Typography variant="body2">
                Date: {new Date(event.date).toLocaleString()}
            </Typography>
            <Typography variant="body2">Status: {event.status}</Typography>
            <Box
                sx={{
                    border: 1,
                    borderColor: 'divider',
                    borderRadius: 1,
                    bgcolor: 'background.paper',
                }}
            >
                <EditorContent editor={editor} />
            </Box>
            <ImageGallery imageIds={event.image_ids} />
        </Box>
    )
}
