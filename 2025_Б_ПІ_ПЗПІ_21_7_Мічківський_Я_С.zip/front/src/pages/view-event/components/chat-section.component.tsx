import { Box, Button, TextField, Typography } from '@mui/material'
import { useState } from 'react'
import { Comment } from '../../../shared/common/interfaces/event.interface.ts'

interface ChatSectionProps {
    comments: Comment[]
    isCommentsAllowed: boolean
    postComment: (content: string) => void
}

export default function ChatSection({
    comments,
    isCommentsAllowed,
    postComment,
}: ChatSectionProps) {
    const [newComment, setNewComment] = useState('')

    const handlePostComment = () => {
        if (newComment.trim()) {
            postComment(newComment)
            setNewComment('')
        }
    }

    return (
        <Box sx={{ mt: 3 }}>
            <Typography variant="h6">Comments</Typography>
            {comments.length === 0 ? (
                <Typography variant="body2" color="text.secondary">
                    No comments yet
                </Typography>
            ) : (
                comments.map((comment) => (
                    <Box key={comment.id} sx={{ mt: 1 }}>
                        <Typography variant="body2">
                            <strong>{comment.user.name}</strong>:{' '}
                            {comment.content}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                            {new Date(comment.created_at).toLocaleString()}
                        </Typography>
                    </Box>
                ))
            )}
            {isCommentsAllowed && (
                <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
                    <TextField
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Write a comment..."
                        fullWidth
                        size="small"
                    />
                    <Button variant="contained" onClick={handlePostComment}>
                        Post
                    </Button>
                </Box>
            )}
        </Box>
    )
}
