import { Box, Typography, useTheme } from '@mui/material';
import AuthLayout from './auth.layout';
import { useLogin } from './hooks/use-login.hook';
import LoginForm from './components/login-form.component';

export default function Login() {
    const { mutate, isPending } = useLogin();
    const theme = useTheme();

    const logoSrc =
        theme.palette.mode === 'light'
            ? '/src/assets/logo-full-light.svg'
            : '/src/assets/logo-full-dark.svg';

    return (
        <AuthLayout>
            <Box
                component="img"
                src={logoSrc}
                alt="Diary Logo"
                sx={{ height: 150, mx: 'auto', mb: 3, display: 'block' }}
            />
            <Typography
                variant="h4"
                align="center"
                sx={{ color: (theme) => theme.palette.primary.main, mb: 3 }}
            >
                Sign In
            </Typography>
            <LoginForm onSubmit={mutate} isLoading={isPending} />
        </AuthLayout>
    );
}