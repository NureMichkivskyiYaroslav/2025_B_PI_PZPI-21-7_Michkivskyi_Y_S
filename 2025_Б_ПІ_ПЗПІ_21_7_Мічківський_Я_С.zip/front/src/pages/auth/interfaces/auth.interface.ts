export interface Credentials {
    email: string;
    password: string;
    name?: string;
}

export interface ProfileResponse {
    token: string;
}

export interface ExchangeTokenResponse {
    idToken: string;
}