import { Formik, Form } from 'formik'
import { Button, useTheme, Typography, Link } from '@mui/material'
import { Link as RouterLink } from 'react-router-dom'
import * as Yup from 'yup'
import AuthInput from './auth-input.component.tsx'

interface LoginFormProps {
    onSubmit: (values: { email: string; password: string }) => void
    isLoading?: boolean
}

const validationSchema = Yup.object({
    email: Yup.string()
        .email('Invalid email address')
        .required('Email is required'),
    password: Yup.string()
        .min(6, 'Password must be at least 6 characters')
        .required('Password is required'),
})

export default function LoginForm({ onSubmit, isLoading }: LoginFormProps) {
    const theme = useTheme()

    return (
        <Formik
            initialValues={{ email: '', password: '' }}
            validationSchema={validationSchema}
            onSubmit={async (values, { setSubmitting }) => {
                try {
                    await onSubmit(values)
                } finally {
                    setSubmitting(false)
                }
            }}
        >
            {({ isSubmitting }) => (
                <Form data-testid="login-form">
                    <AuthInput name="email" label="Email" type="email" />
                    <AuthInput
                        name="password"
                        label="Password"
                        type="password"
                    />
                    <Button
                        type="submit"
                        variant="contained"
                        fullWidth
                        disabled={isLoading || isSubmitting}
                        sx={{
                            mt: 3,
                            py: 1.5,
                            background: theme.palette.primary.main,
                            '&:hover': {
                                background: theme.palette.primary.dark,
                                transform: 'scale(1.02)',
                                transition: 'all 0.2s ease-in-out',
                            },
                        }}
                    >
                        {isLoading || isSubmitting ? 'Loading...' : 'Sign In'}
                    </Button>
                    <Typography
                        variant="body2"
                        sx={{ mt: 2, textAlign: 'center' }}
                    >
                        Don't have an account?{' '}
                        <Link
                            component={RouterLink}
                            to="/register"
                            sx={{ color: theme.palette.primary.main }}
                        >
                            Sign Up
                        </Link>
                    </Typography>
                </Form>
            )}
        </Formik>
    )
}
