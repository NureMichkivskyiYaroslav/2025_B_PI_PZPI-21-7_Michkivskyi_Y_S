import { Formik, Form, FormikHelpers } from 'formik'
import { Button, useTheme, Typography, Link } from '@mui/material'
import { Link as RouterLink } from 'react-router-dom'
import * as Yup from 'yup'
import AuthInput from './auth-input.component.tsx'

interface RegisterFormProps {
    onSubmit: (values: {
        email: string
        password: string
        name: string
    }) => void
    isLoading?: boolean
}

interface FormValues {
    email: string
    password: string
    name: string
}

const validationSchema = Yup.object({
    email: Yup.string()
        .email('Invalid email address')
        .required('Email is required'),
    password: Yup.string()
        .min(6, 'Password must be at least 6 characters')
        .required('Password is required'),
    name: Yup.string()
        .min(3, 'Name must be at least 3 characters')
        .max(20, 'Name must be at most 20 characters')
        .required('Name is required'),
})

export default function RegisterForm({
    onSubmit,
    isLoading,
}: RegisterFormProps) {
    const theme = useTheme()

    return (
        <Formik
            initialValues={{ email: '', password: '', name: '' }}
            validationSchema={validationSchema}
            onSubmit={async (
                values: FormValues,
                { setSubmitting }: FormikHelpers<FormValues>,
            ) => {
                try {
                    onSubmit(values)
                } catch (error) {
                    setSubmitting(false)
                }
            }}
        >
            {({ isSubmitting }) => (
                <Form data-testid="register-form">
                    <AuthInput name="name" label="Name" type="text" />
                    <AuthInput name="email" label="Email" type="email" />
                    <AuthInput
                        name="password"
                        label="Password"
                        type="password"
                    />
                    <Button
                        type="submit"
                        variant="contained"
                        fullWidth
                        disabled={isLoading || isSubmitting}
                        sx={{
                            mt: 3,
                            py: 1.5,
                            background: theme.palette.primary.main,
                            '&:hover': {
                                background: theme.palette.primary.dark,
                                transform: 'scale(1.02)',
                                transition: 'all 0.2s ease-in-out',
                            },
                        }}
                        data-testid="register-submit"
                    >
                        {isLoading || isSubmitting ? 'Loading...' : 'Sign Up'}
                    </Button>
                    <Typography
                        variant="body2"
                        sx={{ mt: 2, textAlign: 'center' }}
                        data-testid="login-link"
                    >
                        Already have an account?{' '}
                        <Link
                            component={RouterLink}
                            to="/login"
                            sx={{ color: theme.palette.primary.main }}
                        >
                            Sign In
                        </Link>
                    </Typography>
                </Form>
            )}
        </Formik>
    )
}
