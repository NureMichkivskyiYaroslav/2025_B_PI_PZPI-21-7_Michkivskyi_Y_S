import { Field, ErrorMessage } from 'formik'
import {
    TextField,
    InputAdornment,
    IconButton,
    Typography,
    useTheme,
} from '@mui/material'
import {
    Email,
    Lock,
    Visibility,
    VisibilityOff,
    Person,
} from '@mui/icons-material'
import { useState } from 'react'

interface AuthInputProps {
    name: string
    label: string
    type: 'email' | 'password' | 'text'
}

export default function AuthInput({ name, label, type }: AuthInputProps) {
    const [showPassword, setShowPassword] = useState(false)
    const theme = useTheme()

    const getStartAdornment = () => {
        switch (type) {
            case 'email':
                return <Email color="action" />
            case 'password':
                return <Lock color="action" />
            case 'text':
                return <Person color="action" />
            default:
                return null
        }
    }

    return (
        <>
            <Field
                as={TextField}
                fullWidth
                name={name}
                label={label}
                type={type === 'password' && showPassword ? 'text' : type}
                margin="normal"
                variant="outlined"
                slotProps={{
                    input: {
                        startAdornment: (
                            <InputAdornment position="start">
                                {getStartAdornment()}
                            </InputAdornment>
                        ),
                        endAdornment:
                            type === 'password' ? (
                                <InputAdornment position="end">
                                    <IconButton
                                        onClick={() =>
                                            setShowPassword(!showPassword)
                                        }
                                        edge="end"
                                        data-cy={`toggle-${name}-visibility`}
                                    >
                                        {showPassword ? (
                                            <VisibilityOff />
                                        ) : (
                                            <Visibility />
                                        )}
                                    </IconButton>
                                </InputAdornment>
                            ) : null,
                    },
                }}
                sx={{
                    '& .MuiOutlinedInput-root': {
                        '&:hover fieldset': {
                            borderColor: theme.palette.primary.main,
                        },
                        '&.Mui-focused fieldset': {
                            borderColor: theme.palette.primary.dark,
                        },
                    },
                    '& .MuiOutlinedInput-input': {
                        paddingLeft: '8px',
                    },
                }}
                data-cy={`input-${name}`}
            />
            <ErrorMessage
                name={name}
                render={(msg) => (
                    <Typography
                        variant="caption"
                        sx={{
                            color: theme.palette.error.main,
                            mb: 1,
                            display: 'block',
                        }}
                        data-cy={`error-${name}`}
                    >
                        {msg}
                    </Typography>
                )}
            />
        </>
    )
}
