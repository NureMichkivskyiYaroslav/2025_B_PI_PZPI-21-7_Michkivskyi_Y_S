import { useMutation } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../../shared/hooks/use-auth.hook'
import { Credentials } from '../interfaces/auth.interface'
import { createFirebaseUser, createProfile, exchangeToken } from '../auth.api'
import { deleteUser } from 'firebase/auth'
import { toast } from 'react-toastify'

export const useRegister = () => {
    const { login } = useAuth()
    const navigate = useNavigate()

    return useMutation({
        mutationFn: async ({
            email,
            password,
            name,
        }: Credentials & { name: string }) => {
            let firebaseUser = null
            try {
                const firebaseResult = await createFirebaseUser({
                    email,
                    password,
                })
                firebaseUser = firebaseResult.user
                const firebaseToken = await firebaseUser.getIdToken()
                const profileResult = await createProfile(
                    firebaseToken,
                    email,
                    name,
                )

                const exchangeResult = await exchangeToken(profileResult.token)
                localStorage.setItem(
                    'user',
                    JSON.stringify({
                        uid: firebaseUser.uid,
                        email,
                        name,
                    }),
                )

                return exchangeResult.idToken
            } catch (error: unknown) {
                if (firebaseUser) {
                    try {
                        await deleteUser(firebaseUser)
                        console.log(
                            'Firebase user deleted due to server failure',
                        )
                    } catch (deleteError) {
                        console.error(
                            'Failed to delete Firebase user:',
                            deleteError,
                        )
                    }
                }
                throw new Error(
                    (error as Error).message || 'Registration failed',
                )
            }
        },
        onSuccess: (token) => {
            login(token)
            navigate('/dashboard')
        },
        onError: (error: Error) => {
            toast.error(error.message)
        },
    })
}
