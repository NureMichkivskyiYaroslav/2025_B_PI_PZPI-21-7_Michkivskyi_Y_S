import { useMutation } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { loginFirebaseUser } from '../auth.api'
import { Credentials } from '../interfaces/auth.interface'
import { useAuth } from '../../../shared/hooks/use-auth.hook'
import { toast } from 'react-toastify'

export const useLogin = () => {
    const { login } = useAuth()
    const navigate = useNavigate()

    return useMutation({
        mutationFn: async (credentials: Credentials) => {
            const firebaseResult = await loginFirebaseUser(credentials)
            return await firebaseResult.user.getIdToken()
        },
        onSuccess: (token) => {
            login(token)
            navigate('/dashboard')
        },
        onError: (error: unknown) => {
            toast.error((error as Error).message)
            return (error as Error).message || 'Login failed'
        },
    })
}
