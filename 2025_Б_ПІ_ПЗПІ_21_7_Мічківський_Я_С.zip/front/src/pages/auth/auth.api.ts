import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
} from 'firebase/auth'
import {
    Credentials,
    ExchangeTokenResponse,
    ProfileResponse,
} from './interfaces/auth.interface'
import { auth } from '../../firebase.config'
import { axiosAuthInstance } from '../../shared/api/axios.instance.ts'

export const createFirebaseUser = async ({ email, password }: Credentials) => {
    return await createUserWithEmailAndPassword(auth, email, password)
}

export const loginFirebaseUser = async ({ email, password }: Credentials) => {
    return await signInWithEmailAndPassword(auth, email, password)
}

export const createProfile = async (
    firebaseToken: string,
    email: string,
    name: string,
) => {
    const response = await axiosAuthInstance.post<ProfileResponse>(
        '/profile',
        { email, name },
        {
            headers: { Authorization: `Bearer ${firebaseToken}` },
        },
    )
    return response.data
}

export const exchangeToken = async (serverToken: string) => {
    const response = await axiosAuthInstance.post<ExchangeTokenResponse>(
        `https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${import.meta.env.VITE_FIREBASE_API_KEY}`,
        {
            token: serverToken,
            returnSecureToken: true,
        },
    )
    return response.data
}
