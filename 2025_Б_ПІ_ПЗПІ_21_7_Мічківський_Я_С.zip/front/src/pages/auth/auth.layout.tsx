import { Box, Container, Paper } from '@mui/material';
import { ReactNode } from 'react';
import ThemeToggle from '../../shared/components/themeToggle.component';

interface AuthLayoutProps {
    children: ReactNode;
}

export default function AuthLayout({ children }: AuthLayoutProps) {
    return (
        <Box
            sx={{
                minHeight: '100vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: (theme) =>
                    `linear-gradient(135deg, ${theme.palette.gradient.start} 0%, ${theme.palette.gradient.end} 100%)`,
            }}
        >
            <Container maxWidth="sm">
                <Paper
                    elevation={6}
                    sx={{
                        p: 4,
                        borderRadius: 3,
                        my:3,
                        background: (theme) => theme.palette.background.paper,
                    }}
                >
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
                        <ThemeToggle />
                    </Box>
                    {children}
                </Paper>
            </Container>
        </Box>
    );
}