import { createTheme } from '@mui/material/styles'

// Light Theme
const lightTheme = createTheme({
    palette: {
        mode: 'light',
        primary: {
            main: '#1976d2', // Blue for buttons and accents
            contrastText: '#fff',
        },
        secondary: {
            main: '#dc004e', // Pink for secondary elements
        },
        background: {
            default: '#f5f5f5', // Light background
            paper: '#fff',
        },
        text: {
            primary: '#000',
            secondary: '#555',
        },
        error: {
            main: '#d32f2f', // Default MUI error color for light theme
        },
        gradient: {
            start: '#1976d2', // Matches primary.main
            end: '#dc004e', // Matches secondary.main
        },
        tag: {
            main: '#64b5f6', // Brighter blue for tags, distinct from primary.main
            contrastText: '#fff', // Matches primary.contrastText
        },
    },
    typography: {
        fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
        h4: {
            fontWeight: 700,
        },
    },
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    borderRadius: 8,
                    textTransform: 'none',
                    padding: '10px 20px',
                },
            },
        },
        MuiTextField: {
            styleOverrides: {
                root: {
                    '& .MuiOutlinedInput-root': {
                        borderRadius: 8,
                    },
                },
            },
        },
    },
})

// Dark Theme
const darkTheme = createTheme({
    palette: {
        mode: 'dark',
        primary: {
            main: '#90caf9', // Lighter blue for contrast
            contrastText: '#000',
        },
        secondary: {
            main: '#f48fb1', // Lighter pink for contrast
        },
        background: {
            default: '#0a0a0a', // Darker background
            paper: '#181818', // Darker paper for forms
        },
        text: {
            primary: '#fff',
            secondary: '#b0b0b0',
        },
        error: {
            main: '#ef5350', // Slightly lighter error color for dark theme visibility
        },
        gradient: {
            start: '#050a51', // Darker blue, matching form aesthetic
            end: '#580e3f', // Darker pink, matching form aesthetic
        },
        tag: {
            main: '#4fc3f7', // Vibrant cyan-blue for tags, distinct from primary.main
            contrastText: '#000', // Matches primary.contrastText
        },
    },
    typography: {
        fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
        h4: {
            fontWeight: 700,
        },
    },
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    borderRadius: 8,
                    textTransform: 'none',
                    padding: '10px 20px',
                },
            },
        },
        MuiTextField: {
            styleOverrides: {
                root: {
                    '& .MuiOutlinedInput-root': {
                        borderRadius: 8,
                    },
                },
            },
        },
    },
})

export { lightTheme, darkTheme }
