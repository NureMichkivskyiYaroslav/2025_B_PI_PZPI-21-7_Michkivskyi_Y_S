export default {
    preset: 'ts-jest',
    testEnvironment: 'jsdom',
    setupFilesAfterEnv: ['<rootDir>/jest.setup.ts'],
    moduleNameMapper: {
        '\\.(svg|png|jpg)$': '<rootDir>/__mocks__/fileMock.js',
    },
}
